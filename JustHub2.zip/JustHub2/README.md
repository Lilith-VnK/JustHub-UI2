# JustHub 3.0.0 — Reconstructed UI Framework

A complete replacement of the previous 2.0.0 monolithic implementation. The package contains both a Rojo-friendly modular source tree and a generated, dependency-free standalone Luau bundle for executor `loadstring` use.

## Distribution files

- `JustHub3.lua` — standalone bundled build; this is the file intended for `loadstring`.
- `src/` — modular implementation, organized by responsibility.
- `build.py` — regenerates the standalone bundle from `src/`.
- `default.project.json` — Rojo project mapping for the modular source.
- `ARCHITECTURE.md` — subsystem responsibilities and lifecycle.
- `API.md` — public API, component options, and compatibility notes.
- `REMOVED_FEATURES.md` — legacy feature decisions.
- `TEST_REPORT.md` — static verification and runtime limitations.

## Delta / standalone usage

Place `JustHub3.lua` where the executor can read it, then execute:

```lua
local source = readfile("JustHub3.lua")
local JustHub = loadstring(source)()

local window = JustHub:CreateWindow({
    Name = "My Hub",
    SubTitle = "Personal control panel",
    Theme = "Darker",
    Width = 760,
    Height = 520,
})

local mainTab = window:addTab("Main", "home")
local controls = mainTab:addSection("Controls")

controls:addToggle({
    Name = "Enabled",
    Default = false,
    Callback = function(value)
        print("Enabled:", value)
    end,
})

controls:addSlider({
    Name = "Power",
    Min = 0,
    Max = 100,
    Step = 1,
    Default = 35,
    Callback = function(value)
        print("Power:", value)
    end,
})
```

The same return value is available from `loadstring(game:HttpGet(yourHostedRawFileUrl))()` when the bundle is hosted by the user. No URL is embedded in this package.

## Modular / Rojo usage

Open `default.project.json` with Rojo and sync the project as a `ModuleScript` tree. The `src` directory maps to the root ModuleScript; its `Modules` child provides the core, service, and UI module registry. Require the root ModuleScript from a client-side context.

The modular layout is intended for editing and development. The standalone build is produced from exactly these source files by `python build.py`.

## Runtime requirements

- Run from a Roblox client context where `Players.LocalPlayer` exists.
- Core Roblox services used: `Players`, `RunService`, `TweenService`, `UserInputService`, `HttpService`, and `SoundService`.
- The default UI parent is `LocalPlayer.PlayerGui`. `UseCoreGui = true` is an optional executor-specific fallback; it is probed safely and falls back to `PlayerGui`.
- `loadstring` itself must be available in the target execution environment. This package does not enable or bypass executor restrictions.
- Config file persistence is optional and requires supported executor filesystem functions (`readfile`, `writefile`, and optionally `delfile`, `isfile`, `makefolder`, `isfolder`). The library reports available capabilities.

## Destruction

Call `JustHub:Destroy()` to disconnect shared input/chroma listeners, cancel owned tasks and tweens, destroy owned instances, and unregister control state. Closing the UI calls this same cleanup path.

## Important security note

`SetKey` / `CheckKey` and `SetUserRole` / `CheckRole` are local client-side convenience mechanisms only. They are not authentication or authorization boundaries. Never place secrets in a client script or rely on local role checks to protect server-side actions. Enforce real permissions on the server.
