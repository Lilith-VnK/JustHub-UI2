# Known limitations and runtime notes

- This workspace cannot execute Roblox Instances, LocalPlayer UI, Delta APIs or real `loadstring`; therefore actual rendering/input/filesystem runtime acceptance must be performed in the target client.
- No Luau compiler/analyzer was available here. The checks performed include structural block balancing and bundle dependency checks, not a claim of compiler-level syntax proof.
- `SetKey`/`CheckKey` and local role ranks can be modified or bypassed by a client. Use server-side validation for security-sensitive actions.
- Built-in localization is English and Indonesian. Changing the active language affects translations requested afterward; already-created text labels are not automatically rebuilt.
- Sound IDs are disabled by default (`0`). Set `JustHub.Sounds.ButtonClick` / `SliderMove` to valid assets before playback.
- Filesystem persistence is executor-dependent. The library works without filesystem access, but save/load/delete return explicit capability errors.
- The original icon asset IDs are preserved as convenience keys. Asset availability and moderation/loading behavior depend on Roblox at runtime.
- The `ScriptBox` component intentionally forwards its text to the caller's callback; it does not execute arbitrary text automatically.
- `UseCoreGui` is opt-in. Some executors or client contexts may block CoreGui parenting; the implementation falls back to PlayerGui.
