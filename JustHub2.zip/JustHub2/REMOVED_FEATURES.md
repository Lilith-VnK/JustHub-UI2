# Legacy feature decisions

| Legacy item | Decision | Reason / replacement |
|---|---|---|
| TransparencyController registry, roles, aliases, property maps, token mirrors, classification and refresh pass | Removed | Actual backgrounds are assigned as opaque at creation. Compatibility shims remain for older public method calls. |
| Monolithic creation helpers and global connection list | Replaced | Module boundaries plus hierarchical resource scopes isolate ownership and cleanup. |
| Separate control value, setter, and metadata sources | Consolidated | StateManager owns built-in state and metadata; the public registry is a compatibility view and external-control adapter. |
| Per-keybind `InputBegan` connection | Removed | One shared key dispatcher serves all keybind components. |
| Slider callback dispatch on every pointer movement | Changed | Drag writes are live but callback/history commit occurs once when the interaction ends. |
| Old `__JustHubMeta` transparency settings in config | Ignored during migration | They contain no user state and no longer have a corresponding setting. |
| Promo notification loop auto-enablement | Removed | It is disabled by default and only runs when explicitly opted in. |
| Empty localization/sound frameworks | Replaced / simplified | Built-in `en`/`id` dictionaries and optional sound playback; sound IDs remain zero until configured. |
| Local KeySystem as if it were secure authentication | Reframed | `SetKey` / `CheckKey` is kept for local UI flow only; it cannot secure client code. |
| Exact-equality role checks | Replaced | Local rank hierarchy supports inherited minimum-role checks and custom ranks. |
| Automatic script text execution in ScriptBox | Not introduced | ScriptBox invokes the user's callback with editor text; it will not call `loadstring` implicitly. |
| Executor filesystem assumptions | Removed | All read/write/delete calls pass through capability-detecting StorageAdapter. |

## Features retained and rebuilt

- All 17 named themes.
- All 13 component types from v2.
- Window, sidebar, tabs, sections, search, drag, resize, minimize, maximize, lock and close.
- Chroma, themes and custom theme registration.
- State, aliases, callbacks, validation, Undo/Redo and configuration migration.
- Notifications, optional promo notifications, localization extension points, sound extension points and local role/key helpers.
