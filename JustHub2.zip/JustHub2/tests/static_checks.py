#!/usr/bin/env python3
"""Workspace-only static checks for JustHub's generated Luau package."""
from pathlib import Path
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
BUNDLE = ROOT / "JustHub3.lua"
MODULES = [
    "Core/Util.lua", "Core/ResourceManager.lua", "Core/ThemeManager.lua",
    "Core/StateManager.lua", "Core/StorageAdapter.lua", "Core/ConfigManager.lua",
    "Services/Localization.lua", "Services/Permissions.lua", "Services/Sound.lua",
    "UI/Components.lua", "UI/Window.lua", "UI/Notifications.lua",
]
COMPONENTS = [
    "addMenu", "addChromaToggle", "addToggle", "addSlider", "addLabel",
    "addTextBox", "addDropdown", "addMultiDropdown", "addColorPicker",
    "addScriptBox", "addBind", "addButton", "addConfigManager",
]
PUBLIC_API = [
    "CreateWindow", "InitializeUI", "UpdateTheme", "SetTheme", "RegisterTheme",
    "ToggleUIVisibility", "PlaySound", "SetLanguage", "LocalizeText",
    "RegisterControl", "SetUserRole", "CheckRole", "Undo", "Redo", "ApplyConfig",
    "SaveConfig", "LoadConfig", "SetKey", "CheckKey", "Notify", "PromoNotify", "Destroy",
]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def luau_block_balance(path: Path) -> None:
    source = path.read_text(encoding="utf-8")
    pattern = re.compile(
        r'''--\[\[.*?\]\]|--[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\[\[(?:.|\n)*?\]\]|[A-Za-z_][A-Za-z0-9_]*''',
        re.S,
    )
    tokens = []
    for match in pattern.finditer(source):
        token = match.group(0)
        if token.startswith("--") or token.startswith('"') or token.startswith("'") or token.startswith("[["):
            continue
        tokens.append(token)

    stack = []
    for token in tokens:
        if token in ("function", "if", "repeat"):
            stack.append({"kind": token})
        elif token in ("for", "while"):
            stack.append({"kind": token, "awaiting_do": True})
        elif token == "do":
            loop = next((entry for entry in reversed(stack)
                         if entry["kind"] in ("for", "while") and entry.get("awaiting_do")), None)
            if loop:
                loop["awaiting_do"] = False
            else:
                stack.append({"kind": "do"})
        elif token == "end":
            require(bool(stack), f"{path}: unexpected end")
            popped = stack.pop()
            require(popped["kind"] != "repeat", f"{path}: repeat must close with until")
        elif token == "until":
            require(bool(stack) and stack[-1]["kind"] == "repeat", f"{path}: unmatched until")
            stack.pop()
    require(not stack, f"{path}: unclosed blocks: {[entry['kind'] for entry in stack]}")


def main() -> None:
    for relative in MODULES:
        path = SRC / relative
        require(path.is_file(), f"Missing module: {relative}")
        luau_block_balance(path)

    project = json.loads((ROOT / "default.project.json").read_text(encoding="utf-8"))
    require(project["tree"].get("$path") == "src", "Rojo mapping does not target src/")

    components_source = (SRC / "UI/Components.lua").read_text(encoding="utf-8")
    for method in COMPONENTS:
        require(f"function Methods:{method}(" in components_source, f"Missing component method {method}")
    require(len(re.findall(r"function Methods:add\w+", components_source)) == 13,
            "Expected exactly 13 component constructors")

    theme_source = (SRC / "Core/ThemeManager.lua").read_text(encoding="utf-8")
    theme_block = theme_source.split("local THEMES = {", 1)[1].split("\n}", 1)[0]
    themes = re.findall(r"^\s{4}([A-Za-z][A-Za-z0-9_]*)\s*=\s*\{", theme_block, re.M)
    require(len(themes) == 17, f"Expected 17 themes, found {len(themes)}")

    entry = (SRC / "init.lua").read_text(encoding="utf-8")
    for method in PUBLIC_API:
        require(f"function JustHub:{method}(" in entry, f"Missing public API method {method}")
    require("TransparencyController" not in "\n".join(p.read_text(encoding="utf-8") for p in SRC.rglob("*.lua")),
            "Legacy transparency controller is still present")

    subprocess.run([sys.executable, str(ROOT / "build.py")], check=True, capture_output=True, text=True)
    bundle = BUNDLE.read_text(encoding="utf-8")
    require("require(script" not in bundle, "Standalone bundle still requires a Roblox ModuleScript tree")
    require("local Modules = require(script:WaitForChild(\"Modules\"))" not in bundle,
            "Standalone bundle still has a module registry require")
    require("JustHub 3.0.0" in bundle, "Standalone bundle header is missing")
    require(bundle.count("-- ===== MODULE: ") == len(MODULES), "Not every module was bundled")
    require(bundle.count("BackgroundTransparency = 0") >= 35,
            "Opaque surface assignments appear unexpectedly low")
    for method in COMPONENTS:
        require(f"function Methods:{method}(" in bundle, f"Bundle missing component {method}")
    luau_block_balance(BUNDLE)

    print("PASS: modular source inventory and module files")
    print("PASS: 13 component constructors")
    print("PASS: 17 built-in themes")
    print("PASS: backward-compatible public API inventory")
    print("PASS: no legacy transparency controller")
    print("PASS: standalone bundle has no ModuleScript require dependency")
    print("PASS: standalone bundle contains all 12 modules and opaque surfaces")
    print("PASS: Luau block-balance checks on all modules and generated bundle")
    print("NOTE: These are static checks, not Roblox/Delta execution or compiler tests.")


if __name__ == "__main__":
    main()
