# Architecture

## Runtime composition

```text
src/init.lua (public API / bootstrap)
├── Core
│   ├── Util.lua              shared validation, cloning, safe calls, IDs
│   ├── ResourceManager.lua   hierarchical ownership scopes and cleanup
│   ├── StateManager.lua     canonical control state, validation, aliases, history
│   ├── ThemeManager.lua     design tokens, theme bindings, chroma scheduler
│   ├── StorageAdapter.lua   executor filesystem capability adapter
│   └── ConfigManager.lua    versioned JSON serialization and migration
├── Services
│   ├── Localization.lua     en/id dictionaries and custom language registration
│   ├── Permissions.lua      local role hierarchy
│   └── Sound.lua            optional scoped sound playback
└── UI
    ├── Window.lua           window, tabs, sections, navigation and input handling
    ├── Components.lua       all 13 component factories and shared input dispatch
    └── Notifications.lua    scoped UI notifications and fallback notification
```

`src/Modules/init.lua` is the module registry for the Rojo tree. `build.py` inlines the same modules as isolated closures into `JustHub3.lua`, then appends `src/init.lua` with the registry reference replaced. The generated bundle has no `require(script...)` dependency and requires no external package.

## State flow

A component creates one `StateManager` record with a stable path-like ID (`Tab/Section/Control`, plus a numeric suffix for same-name duplicates). The record owns the default/current value, validator, renderer, callback, and metadata. `Set` validates first, updates the canonical value, renders, records history, and dispatches callbacks asynchronously with error protection. Rendering failure rolls the value back. Slider drag uses live updates without callback/history churn and emits one callback plus one history record when editing ends.

Short-name aliases remain available only while unambiguous. Once two controls share a short name, the alias is disabled and callers must use the full ID. Config application prefers canonical IDs and falls back to unique aliases. Removing one control removes only that control's history entries; it does not erase unrelated undo history.

## Resource ownership

`ResourceManager` uses a parent/child scope tree. The root scope owns shared services and the window scope; tabs, sections, individual controls, notifications, loading UI, and sound instances create child scopes. A scope can own:

- RBXScriptConnections
- Tweens, indexed per target/property to cancel conflicting tweens
- task threads and delayed callbacks
- Instances
- child scopes and arbitrary cleanup callbacks

Destroying a component or its owning parent disconnects and cancels only resources in that scope. Destroying the library walks the tree and clears all owned resources.

## Rendering and opacity

The interface is rebuilt around a centralized theme manager and design tokens. Actual visual surfaces (window, sidebar, cards, controls, inputs, dropdowns, buttons, and notifications) are explicitly created with `BackgroundTransparency = 0`; text/layout-only elements and click hitboxes retain transparent backgrounds where that is necessary. `UIStroke.Transparency` is also set to zero. The former transparency-role registry, aliases, token mirror, classification pass, and refresh/enforcement loop are removed.

The 17 original named themes are retained. Theme bindings update only registered properties. Chroma uses a single Heartbeat connection at a throttled rate and runs only while enabled and while registered objects remain.

## Configuration and migration

The current document schema is version 4:

```json
{
  "__JustHub": {
    "Version": 4,
    "Framework": "JustHub",
    "FrameworkVersion": "3.0.0",
    "SavedAt": 0
  },
  "Values": {}
}
```

Color3 values are represented by tagged RGB objects. The loader accepts legacy root-level configuration objects (including v2/v3 Color3 tags), strips the old transparency metadata node, and applies values to currently registered controls. Unknown controls are counted as skipped. Invalid JSON, malformed tags, unsupported value types, cyclic tables, and over-deep nesting are reported as errors.

Filesystem functions are discovered once by `StorageAdapter` and always invoked through protected calls. Their absence does not prevent UI initialization; it only disables the corresponding save/load/delete operation.

## Service decisions

- Localization: built-in English and Indonesian dictionaries; additional dictionaries can be registered. Text is localized when components are constructed; calling `SetLanguage` does not retroactively rewrite already-created labels.
- Permissions: local role hierarchy (`guest`, `member`, `moderator`, `admin`) supports rank comparisons and custom roles. It is not server security.
- Key system: local exact-key convenience check only; it is not secure authentication.
- Sound: optional and disabled until non-zero sound asset IDs are configured.
- Promo notifications: disabled by default and opt-in.
