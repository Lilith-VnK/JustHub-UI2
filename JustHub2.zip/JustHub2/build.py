#!/usr/bin/env python3
"""Build JustHub's standalone loadstring distribution from modular Luau sources."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
OUTPUT = ROOT / "JustHub3.lua"

MODULES = [
    ("Util", "Core/Util.lua"),
    ("ResourceManager", "Core/ResourceManager.lua"),
    ("ThemeManager", "Core/ThemeManager.lua"),
    ("StateManager", "Core/StateManager.lua"),
    ("StorageAdapter", "Core/StorageAdapter.lua"),
    ("ConfigManager", "Core/ConfigManager.lua"),
    ("Localization", "Services/Localization.lua"),
    ("Permissions", "Services/Permissions.lua"),
    ("Sound", "Services/Sound.lua"),
    ("Components", "UI/Components.lua"),
    ("Window", "UI/Window.lua"),
    ("Notifications", "UI/Notifications.lua"),
]

REQUIRE_LINE = 'local Modules = require(script:WaitForChild("Modules"))'


def main() -> None:
    entry = (SRC / "init.lua").read_text(encoding="utf-8")
    if entry.count(REQUIRE_LINE) != 1:
        raise SystemExit("Could not find exactly one modular entry-point require line")

    chunks = [
        "--[[\n"
        "    JustHub 3.0.0 — Standalone Luau build\n"
        "    Generated from the modular sources in src/.\n"
        "    Compatible entry pattern: loadstring(source)()\n"
        "    No remote module downloads or external libraries are required.\n"
        "]]\n\n",
        "local Modules = {}\n",
    ]
    for module_name, relative_path in MODULES:
        source_path = SRC / relative_path
        source = source_path.read_text(encoding="utf-8").rstrip()
        chunks.append(f"\n-- ===== MODULE: {module_name} ({relative_path}) =====\n")
        chunks.append(f"Modules.{module_name} = (function()\n{source}\nend)()\n")

    chunks.append("\n-- ===== APPLICATION ENTRY POINT =====\n")
    chunks.append(entry.replace(REQUIRE_LINE, "-- Module registry is inlined above.", 1))
    OUTPUT.write_text("".join(chunks), encoding="utf-8", newline="\n")
    print(f"Built {OUTPUT} ({OUTPUT.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
