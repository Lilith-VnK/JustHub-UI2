# Public API and component reference

## Window lifecycle

```lua
local window = JustHub:CreateWindow(options)
-- or:
local ok, window = JustHub:InitializeUI(options)

local tab = window:addTab("Main", "home")
local section = tab:addSection("General")
window:Toggle() -- Show(), Hide(), SetTitle(), SetSubtitle(), SetSize(), Destroy()
JustHub:Destroy()
```

`CreateWindow` options: `Name`, `SubTitle`, `Theme` (registered name or a six-color theme table), `Width`, `Height`, `SidebarWidth`, `Parent`, `DisplayOrder`, and `UseCoreGui` (opt-in executor path; PlayerGui is the default).

Tabs accept an optional icon key from `JustHub.Icons` (`activity`, `check`, `cog`, `folder`, `home`, `menu`, `search`, `settings`, `user`). Sections expose lowercase methods and PascalCase aliases.

## Components

All component methods are available in lowercase and PascalCase forms (`addToggle` / `AddToggle`, etc.). Components are scoped to their section and clean themselves up when destroyed.

| Component | Main options | Notes |
|---|---|---|
| Menu | `name` | Static opaque section divider/header. |
| ChromaToggle | none | Creates a toggle controlling global chroma animation. |
| Toggle | `Name`, `Default`, `Callback`, `FireOnInit` | Boolean state. |
| Slider | `Name`, `Min`, `Max`, `Step` or `Float`, `Default`, `Callback`, `FireOnInit` | Numeric, finite, clamped and snapped to the configured step. Callback is dispatched once at drag completion. |
| Label | string or `Text`, `Name`, `Align`, `Height`, `TextSize`, `ColorKey` | Returns `{Frame, SetText, Destroy}`. |
| TextBox | `Name`, `Default`, `Placeholder`, `Callback` | String state commits on focus loss. |
| Dropdown | `Name`, `Default`, `Items`, `Presets`, `Callback` | String selection, searchable options; returned object has `Refresh`, `Clear`, `GetValue`, `SetValue`, `Destroy`. |
| MultiDropdown | `Name`, `Default`, `Items`, `Presets`, `Callback` | Array of unique strings; supports select all/clear all; returned object has `Refresh`, `GetValue`, `SetValue`, `Destroy`. |
| ColorPicker | `Name`, `Default` (`Color3`), `Callback` | Presets, RGB fields, and hex input. |
| ScriptBox | `Name`, `Default`, `Placeholder`, `ButtonText`, `Callback` | Passes the editor text to the provided callback. It does not automatically execute user text. |
| Bind | `Name`, `Default` (KeyCode name), `Callback` | One shared InputBegan listener dispatches all registered keybinds. Movement keys and common system keys are intentionally blocked. |
| Button | `Name`, `ButtonText`, `Callback` | Runs the provided callback with protected error handling. |
| ConfigManager | none | UI for save, load, and delete profile operations. |

## Control and history API

- `RegisterControl(id, setter, metadata)` registers an external control. Supply `metadata.getValue` (or `GetValue`) to include that value in saved configurations.
- `ConfigData` is the canonical values table for built-in components.
- `ControlRegistry`, `ControlAliases`, and `Controls` are exposed for compatibility/introspection.
- `Undo()`, `Redo()`, `AddUndo(id, oldValue, newValue)`, and `ApplyConfig(values)` manage the state history and restoration pipeline.
- `ApplyConfig` applies controls that are registered at the time it is called. It is not a deferred queue for controls created later.

## Themes and utilities

- `RegisterTheme(name, definition)` expects six `Color3` fields: `Color Hub 1`, `Color Hub 2`, `Color Stroke`, `Color Theme`, `Color Text`, and `Color Dark Text`.
- `UpdateTheme(theme)` / `SetTheme(theme)` accepts a registered theme name or a valid theme table.
- `ToggleChroma(enabled)` enables/disables the single global chroma scheduler.
- `PlaySound(name, volume)` plays a configured asset ID; defaults are zero (disabled).
- `SetLanguage(code)`, `RegisterLanguage(code, dictionary)`, and `LocalizeText(key)` expose built-in `en` and `id` dictionaries plus extensions.
- `Notify({Title, Message, Duration, ShowProgress})` creates an in-UI notification or falls back to a Roblox core notification.
- `PromoNotify(interval)` runs an opt-in periodic promo; set `PromoNotifyEnabled = true` before calling. It is disabled by default.

## Compatibility methods

`SetTransparency` validates the supplied legacy numeric argument but keeps visual surfaces opaque. `RegisterTransparency` is reduced to a direct one-time opaque assignment for `GuiObject.BackgroundTransparency` or `UIStroke.Transparency`; `UnregisterTransparency` is a no-op. These shims preserve callability but do not recreate the old registry semantics.

`SetKey` and `CheckKey` remain local-only convenience helpers. `SetUserRole`, `CheckRole`, and `RegisterRole` use the new rank-based local role hierarchy.
