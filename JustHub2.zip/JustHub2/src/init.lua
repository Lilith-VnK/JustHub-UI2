local Modules = require(script:WaitForChild("Modules"))

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local HttpService = game:GetService("HttpService")
local SoundService = game:GetService("SoundService")

local Util = Modules.Util
local ResourceManager = Modules.ResourceManager
local RootScope = ResourceManager.new("JustHubRoot")
local Theme = Modules.ThemeManager.new(RunService, RootScope)
local State = Modules.StateManager.new({HistoryLimit = 100})
local Storage = Modules.StorageAdapter.new()
local Localization = Modules.Localization.new()
local Permissions = Modules.Permissions.new()
local SoundController = Modules.Sound({
    Instance = Instance,
    SoundService = SoundService,
    RootScope = RootScope,
}).new()

local JustHub = {}
JustHub.__index = JustHub

JustHub.Info = {
    Name = "JustHub",
    Version = "3.0.0",
    SchemaVersion = 4,
}
JustHub.Save = {
    UISize = {760, 520},
    TabSize = 168,
    Theme = "Darker",
    Locked = false,
    Transparency = 0, -- Legacy compatibility only; opacity is no longer configurable.
}
JustHub.Themes = Theme.Themes
JustHub.DesignTokens = Theme.Tokens
JustHub.Icons = {
    activity = "rbxassetid://10709752035",
    check = "rbxassetid://10709790644",
    cog = "rbxassetid://10709810948",
    folder = "rbxassetid://10723387563",
    home = "rbxassetid://10723405786",
    menu = "rbxassetid://10723406085",
    search = "rbxassetid://10723406260",
    settings = "rbxassetid://10723406450",
    user = "rbxassetid://10723406670",
}
JustHub.ConfigData = State.Values
JustHub.ControlRegistry = {}
JustHub.ControlAliases = {}
JustHub.AmbiguousControlAliases = State.AmbiguousAliases
JustHub.Controls = State.Controls
JustHub.Localization = Localization.Languages
JustHub.CurrentLang = Localization.Current
JustHub.UserRole = Permissions.CurrentRole
JustHub.UndoStack = State.UndoStack
JustHub.RedoStack = State.RedoStack
JustHub.Sounds = SoundController.Sounds
JustHub.Connections = RootScope.Connections
JustHub.ScreenGuis = {}
JustHub.ThemeObjects = Theme.Bindings
JustHub.ChromaObjects = Theme.Chroma
JustHub.ChromaEnabled = false
JustHub.KeySystem = {Enabled = false, Key = ""}
JustHub.PromoNotifyEnabled = false
JustHub._destroyed = false
JustHub._initializing = false
JustHub._promoThread = nil
JustHub._notificationScopes = {}
JustHub._customTheme = nil
JustHub.ResourceManager = RootScope
JustHub.StateManager = State
JustHub.ThemeManager = Theme
JustHub.StorageAdapter = Storage
JustHub.LocalizationManager = Localization
JustHub.Permissions = Permissions

local Notifications = Modules.Notifications({
    Instance = Instance,
    Enum = Enum,
    Theme = Theme,
    RootScope = RootScope,
    TweenInfo = TweenInfo,
    Library = JustHub,
})

JustHub.ConfigManager = Modules.ConfigManager.new(
    HttpService,
    State,
    Storage,
    function(title, message, duration)
        JustHub:Notify({Title = title, Message = message, Duration = duration})
    end
)

local function registerBuiltinControl(id, handle, metadata)
    local setter = function(value)
        local ok, err = handle:Set(value)
        if not ok then
            error(err, 0)
        end
        return ok
    end
    JustHub.ControlRegistry[id] = setter
    JustHub.Controls[id] = metadata
    local shortName = metadata and metadata.shortName
    if type(shortName) == "string" and shortName ~= "" then
        if State.AmbiguousAliases[shortName] then
            JustHub.ControlAliases[shortName] = nil
        elseif State.Aliases[shortName] == id then
            JustHub.ControlAliases[shortName] = setter
        end
    end
    return setter
end

local Components = Modules.Components({
    Instance = Instance,
    Enum = Enum,
    Util = Util,
    TweenInfo = TweenInfo,
    UserInputService = UserInputService,
    Theme = Theme,
    State = State,
    RootScope = RootScope,
    Library = JustHub,
    Localize = function(key) return Localization:Get(key) end,
    RegisterBuiltinControl = registerBuiltinControl,
})

local WindowModule = Modules.Window({
    Instance = Instance,
    Enum = Enum,
    Players = Players,
    UserInputService = UserInputService,
    Theme = Theme,
    RootScope = RootScope,
    Components = Components,
    Library = JustHub,
    TweenInfo = TweenInfo,
    Util = Util,
    Localize = function(key) return Localization:Get(key) end,
})

function JustHub:IsAlive()
    return not self._destroyed
end

function JustHub:RegisterControl(id, setter, metadata)
    if not self:IsAlive() then
        return false, "JustHub has been destroyed"
    end
    local ok, err = State:RegisterExternal(id, setter, metadata)
    if not ok then
        warn("[JustHub] RegisterControl failed: " .. tostring(err))
        return false, err
    end
    self.ControlRegistry[id] = setter
    self.Controls[id] = metadata or {}
    local shortName = metadata and (metadata.shortName or metadata.ShortName)
    if type(shortName) == "string" and shortName ~= "" then
        if State.AmbiguousAliases[shortName] then
            self.ControlAliases[shortName] = nil
        elseif State.Aliases[shortName] == id then
            self.ControlAliases[shortName] = setter
        end
    end
    return true
end

function JustHub:SetUserRole(roleName)
    local ok, err = Permissions:SetRole(roleName)
    if ok then
        self.UserRole = Permissions.CurrentRole
    end
    return ok, err
end

function JustHub:CheckRole(requiredRole)
    return Permissions:Check(requiredRole)
end

function JustHub:RegisterRole(name, rank)
    return Permissions:RegisterRole(name, rank)
end

function JustHub:AddUndo(controlKey, oldValue, newValue)
    return State:AddUndo(controlKey, oldValue, newValue)
end

function JustHub:Undo()
    return State:Undo()
end

function JustHub:Redo()
    return State:Redo()
end

function JustHub:ApplyConfig(configData)
    return State:ApplyConfig(configData)
end

function JustHub:RegisterTheme(name, definition)
    local ok, err = Theme:Register(name, definition)
    if not ok then
        warn("[JustHub] RegisterTheme failed: " .. tostring(err))
    end
    return ok, err
end

function JustHub:UpdateTheme(newTheme)
    local ok, err = Theme:Apply(newTheme)
    if not ok then
        return false, err
    end
    if type(newTheme) == "table" then
        self._customTheme = table.clone(newTheme)
        self.Save.Theme = "Custom"
    else
        self._customTheme = nil
        self.Save.Theme = newTheme
    end
    return true
end

function JustHub:SetTheme(newTheme)
    return self:UpdateTheme(newTheme)
end

function JustHub:UpdateThemeObject(instance, property, themeKey)
    return Theme:UpdateBinding(instance, property, themeKey)
end

function JustHub:ToggleChroma(enabled)
    self.ChromaEnabled = Theme:SetChroma(enabled)
    return self.ChromaEnabled
end

function JustHub:UnregisterChroma(instance, property)
    Theme:UnregisterChroma(instance, property)
end

function JustHub:PlaySound(name, volume)
    return SoundController:Play(name, volume)
end

function JustHub:SetLanguage(language)
    local ok, err = Localization:SetLanguage(language)
    if ok then
        self.CurrentLang = Localization.Current
    end
    return ok, err
end

function JustHub:RegisterLanguage(language, dictionary)
    return Localization:RegisterLanguage(language, dictionary)
end

function JustHub:LocalizeText(textKey)
    return Localization:Get(tostring(textKey or ""))
end

function JustHub:SaveConfig(fileName)
    return self.ConfigManager:Save(fileName)
end

function JustHub:LoadConfig(fileName)
    return self.ConfigManager:Load(fileName)
end

function JustHub:Notify(options)
    if not self:IsAlive() then
        return nil
    end
    return Notifications.Notify(options)
end

function JustHub:PromoNotify(interval)
    if not self.PromoNotifyEnabled then
        return false, "Promo notifications are disabled"
    end
    if self._promoThread then
        return false, "Promo notification loop is already running"
    end
    interval = math.clamp(tonumber(interval) or 60, 10, 3600)
    self._promoThread = RootScope:Spawn(function(isAlive)
        while isAlive() and self.PromoNotifyEnabled and self.ScreenGui and self.ScreenGui.Parent do
            self:Notify({
                Title = "JustHub",
                Message = "Thanks for using JustHub " .. self.Info.Version,
                Duration = 3,
                ShowProgress = true,
            })
            task.wait(interval)
        end
        self._promoThread = nil
    end)
    return true
end

function JustHub:ToggleUIVisibility()
    if self.Window then
        self.Window:Toggle()
        return true
    end
    if self.ScreenGui and self.ScreenGui.Parent then
        self.ScreenGui.Enabled = not self.ScreenGui.Enabled
        return true
    end
    return false
end

-- Compatibility shim: no registry or refresh loop remains. Only actual
-- visual surfaces are forced to an opaque background.
function JustHub:RegisterTransparency(instance, _, property)
    if not instance then return false end
    property = property or "BackgroundTransparency"
    if property == "BackgroundTransparency" then
        local ok = pcall(function()
            if instance:IsA("GuiObject") then instance.BackgroundTransparency = 0 else error("Not a GuiObject") end
        end)
        return ok
    end
    if property == "Transparency" then
        local ok = pcall(function()
            if instance:IsA("UIStroke") then instance.Transparency = 0 else error("Not a UIStroke") end
        end)
        return ok
    end
    return false
end

function JustHub:UnregisterTransparency()
    -- Kept only as a no-op compatibility wrapper; no transparency registry exists.
    return true
end

function JustHub:SetTransparency(value)
    if not Util.IsFinite(tonumber(value)) then
        return false, "Transparency value must be finite"
    end
    self.Save.Transparency = 0
    return true, "The new design system uses opaque visual surfaces"
end

function JustHub:SetKey(key)
    if type(key) ~= "string" or key == "" then
        return false, "Key must be a non-empty string"
    end
    self.KeySystem.Enabled = true
    self.KeySystem.Key = key
    return true
end

function JustHub:CheckKey(inputKey)
    if not self.KeySystem.Enabled then
        return true
    end
    return type(inputKey) == "string" and inputKey == self.KeySystem.Key
end

function JustHub:CreateWindow(options)
    if not self:IsAlive() then
        return nil, "JustHub has been destroyed"
    end
    if self.Window and self.ScreenGui and self.ScreenGui.Parent then
        return self.Window
    end
    options = type(options) == "table" and options or {}
    local selectedTheme = options.Theme or ((self.Save.Theme == "Custom" and self._customTheme) and self._customTheme) or self.Save.Theme or "Darker"
    if type(selectedTheme) == "string" then
        if not Theme.Themes[selectedTheme] then selectedTheme = "Darker" end
    elseif not Theme:IsValid(selectedTheme) then
        selectedTheme = "Darker"
    end
    local themeOk, themeError = Theme:Apply(selectedTheme)
    if not themeOk then
        warn("[JustHub] Initial theme fallback: " .. tostring(themeError))
        Theme:Apply("Darker")
        selectedTheme = "Darker"
    end
    if type(selectedTheme) == "table" then
        self._customTheme = table.clone(selectedTheme)
        self.Save.Theme = "Custom"
    else
        self.Save.Theme = selectedTheme
    end

    local ok, result = pcall(function()
        return WindowModule.new(options)
    end)
    if not ok then
        warn("[JustHub] CreateWindow failed: " .. tostring(result))
        return nil, result
    end
    self.Window = result
    self.ScreenGui = result.ScreenGui
    return result
end

function JustHub:ShowLoadingScreen(duration, callback)
    if not self:IsAlive() then return false end
    duration = math.clamp(tonumber(duration) or 1.5, 0, 15)
    local player = Players.LocalPlayer
    if not player then return false end
    local parent = player:FindFirstChildOfClass("PlayerGui") or player:WaitForChild("PlayerGui")
    local scope = RootScope:CreateScope("LoadingScreen")
    local screen = Instance.new("ScreenGui")
    screen.Name = "JustHubLoadingScreen"
    screen.ResetOnSpawn = false
    screen.IgnoreGuiInset = true
    screen.Parent = parent
    scope:TrackInstance(screen)
    local backdrop = Instance.new("Frame")
    backdrop.Size = UDim2.fromScale(1, 1)
    backdrop.BackgroundColor3 = Theme:Get("Color Hub 1")
    backdrop.BackgroundTransparency = 0
    backdrop.BorderSizePixel = 0
    backdrop.Parent = screen
    Theme:Bind(backdrop, "BackgroundColor3", "Color Hub 1")
    local panel = Instance.new("Frame")
    panel.AnchorPoint = Vector2.new(0.5, 0.5)
    panel.Position = UDim2.fromScale(0.5, 0.5)
    panel.Size = UDim2.fromOffset(280, 112)
    panel.BackgroundColor3 = Theme:Get("Color Hub 2")
    panel.BackgroundTransparency = 0
    panel.BorderSizePixel = 0
    panel.Parent = backdrop
    Theme:Bind(panel, "BackgroundColor3", "Color Hub 2")
    Instance.new("UICorner", panel).CornerRadius = UDim.new(0, 12)
    local heading = Instance.new("TextLabel")
    heading.BackgroundTransparency = 1
    heading.Position = UDim2.new(0, 16, 0, 14)
    heading.Size = UDim2.new(1, -32, 0, 24)
    heading.Font = Enum.Font.GothamBold
    heading.TextSize = 16
    heading.Text = "JustHub"
    heading.TextColor3 = Theme:Get("Color Text")
    heading.TextXAlignment = Enum.TextXAlignment.Left
    heading.Parent = panel
    Theme:Bind(heading, "TextColor3", "Color Text")
    local rail = Instance.new("Frame")
    rail.Position = UDim2.new(0, 16, 0, 68)
    rail.Size = UDim2.new(1, -32, 0, 6)
    rail.BackgroundColor3 = Theme:Get("Color Hub 1")
    rail.BackgroundTransparency = 0
    rail.BorderSizePixel = 0
    rail.Parent = panel
    Theme:Bind(rail, "BackgroundColor3", "Color Hub 1")
    Instance.new("UICorner", rail).CornerRadius = UDim.new(1, 0)
    local fill = Instance.new("Frame")
    fill.Size = UDim2.new(0, 0, 1, 0)
    fill.BackgroundColor3 = Theme:Get("Color Theme")
    fill.BackgroundTransparency = 0
    fill.BorderSizePixel = 0
    fill.Parent = rail
    Theme:Bind(fill, "BackgroundColor3", "Color Theme")
    Instance.new("UICorner", fill).CornerRadius = UDim.new(1, 0)
    scope:Tween(fill, TweenInfo.new(math.max(0.05, duration), Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        Size = UDim2.new(1, 0, 1, 0),
    })
    scope:Delay(duration, function()
        scope:Destroy()
        if type(callback) == "function" and self:IsAlive() then
            Util.SafeCall("Loading callback", callback)
        end
    end)
    return true
end

function JustHub:InitializeUI(options)
    if not self:IsAlive() or self._initializing then
        return false, "Initialization is already running or JustHub is destroyed"
    end
    if self.Window then
        return true, self.Window
    end
    self._initializing = true
    local window, err = self:CreateWindow(options)
    self._initializing = false
    if not window then
        self:Notify({Title = "Initialization failed", Message = tostring(err), Duration = 5})
        return false, err
    end
    return true, window
end

function JustHub:GetConfigCapabilities()
    return Storage:Capabilities()
end

function JustHub:Destroy()
    if self._destroyed then
        return
    end
    self._destroyed = true
    self.PromoNotifyEnabled = false
    self._initializing = false
    self._promoThread = nil

    Theme:Destroy()
    State:Destroy()
    Permissions:Destroy()
    RootScope:Destroy()

    table.clear(self.ControlRegistry)
    table.clear(self.ControlAliases)
    table.clear(self.ScreenGuis)
    self.ScreenGui = nil
    self.Window = nil
    self.NotificationContainer = nil
    self._customTheme = nil
    self.ConfigData = {}
    self._notificationScopes = {}
end

return JustHub
