return function(context)
    local Instance = context.Instance
    local Enum = context.Enum
    local Theme = context.Theme
    local RootScope = context.RootScope
    local TweenInfo = context.TweenInfo
    local Library = context.Library

    local Notifications = {}

    local function make(className, properties, parent)
        local object = Instance.new(className)
        for property, value in pairs(properties or {}) do
            pcall(function() object[property] = value end)
        end
        if parent then object.Parent = parent end
        return object
    end

    local function bind(object, property, key)
        Theme:Bind(object, property, key)
    end

    function Notifications.Notify(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Title or "JustHub")
        local message = tostring(options.Message or "")
        local duration = tonumber(options.Duration) or 4
        duration = math.clamp(duration, 0, 60)
        local showProgress = options.ShowProgress == true
        local container = Library.NotificationContainer
        if not container or not container.Parent then
            local ok, err = pcall(function()
                game:GetService("StarterGui"):SetCore("SendNotification", {
                    Title = title,
                    Text = message,
                    Duration = duration,
                })
            end)
            if not ok then
                warn("[JustHub] Notification fallback unavailable: " .. tostring(err))
            end
            return nil
        end

        local scope = RootScope:CreateScope("Notification:" .. title)
        local frame = make("Frame", {
            Name = "NotificationSurface",
            Size = UDim2.new(1, 0, 0, 0),
            BackgroundColor3 = Theme:Get("Color Hub 2"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ClipsDescendants = true,
            LayoutOrder = math.floor(os.clock() * 1000),
            ZIndex = 101,
        }, container)
        scope:TrackInstance(frame)
        scope:Connect(frame.Destroying, function() scope:Destroy() end)
        bind(frame, "BackgroundColor3", "Color Hub 2")
        make("UICorner", {CornerRadius = UDim.new(0, 9)}, frame)
        local border = make("UIStroke", {
            Color = Theme:Get("Color Stroke"),
            Thickness = 1,
            Transparency = 0,
        }, frame)
        bind(border, "Color", "Color Stroke")
        local accent = make("Frame", {
            Position = UDim2.new(0, 0, 0, 0),
            Size = UDim2.new(0, 3, 1, 0),
            BackgroundColor3 = Theme:Get("Color Theme"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 103,
        }, frame)
        bind(accent, "BackgroundColor3", "Color Theme")
        make("TextLabel", {
            Name = "Title",
            Position = UDim2.new(0, 14, 0, 8),
            Size = UDim2.new(1, -26, 0, 20),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Text = title,
            Font = Enum.Font.GothamBold,
            TextSize = 13,
            TextColor3 = Theme:Get("Color Text"),
            TextXAlignment = Enum.TextXAlignment.Left,
            TextTruncate = Enum.TextTruncate.AtEnd,
            ZIndex = 103,
        }, frame)
        local body = make("TextLabel", {
            Name = "Message",
            Position = UDim2.new(0, 14, 0, 31),
            Size = UDim2.new(1, -26, 0, 0),
            AutomaticSize = Enum.AutomaticSize.Y,
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Text = message,
            Font = Enum.Font.Gotham,
            TextSize = 11,
            TextColor3 = Theme:Get("Color Dark Text"),
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Top,
            TextWrapped = true,
            ZIndex = 103,
        }, frame)
        bind(body, "TextColor3", "Color Dark Text")
        local progress
        if showProgress then
            progress = make("Frame", {
                Position = UDim2.new(0, 0, 1, -3),
                Size = UDim2.new(1, 0, 0, 3),
                BackgroundColor3 = Theme:Get("Color Theme"),
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                ZIndex = 104,
            }, frame)
            bind(progress, "BackgroundColor3", "Color Theme")
        end

        scope:Delay(0, function()
            if not scope:IsAlive() then return end
            local height = 8 + 20 + math.max(18, body.TextBounds.Y) + (showProgress and 7 or 4)
            scope:Tween(frame, TweenInfo.new(0.22, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {
                Size = UDim2.new(1, 0, 0, height),
            })
            if progress then
                scope:Tween(progress, TweenInfo.new(math.max(0.05, duration), Enum.EasingStyle.Linear), {
                    Size = UDim2.new(0, 0, 0, 3),
                })
            end
            scope:Delay(duration, function()
                scope:Tween(frame, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
                    Size = UDim2.new(1, 0, 0, 0),
                })
                scope:Delay(0.22, function()
                    scope:Destroy()
                end)
            end)
        end)
        return frame
    end

    return Notifications
end
