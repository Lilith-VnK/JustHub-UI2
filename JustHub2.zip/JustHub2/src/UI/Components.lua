return function(context)
    local Instance = context.Instance
    local Enum = context.Enum
    local Util = context.Util
    local TweenInfo = context.TweenInfo
    local UserInputService = context.UserInputService
    local Theme = context.Theme
    local State = context.State
    local Library = context.Library
    local RootScope = context.RootScope

    local Methods = {}
    local keybindRegistry = {}

    -- One shared input listener serves every keybind control in this library.
    if RootScope then
        RootScope:Connect(UserInputService.InputBegan, function(inputObject, processed)
            if inputObject.UserInputType ~= Enum.UserInputType.Keyboard then return end
            local keyName = inputObject.KeyCode.Name
            for record in pairs(keybindRegistry) do
                if record.Scope:IsAlive() then
                    if record.Capturing then
                        record.Capturing = false
                        record.Input:ReleaseFocus()
                        local normalized = record.Normalize(keyName)
                        if normalized ~= "None" then
                            record.Handle:Set(normalized)
                        else
                            record.Input.Text = record.Handle:Get()
                        end
                    elseif not processed and record.Handle:Get() ~= "None" and keyName == record.Handle:Get() then
                        if record.Callback then
                            Util.SafeCall("Keybind callback " .. record.Title, record.Callback)
                        end
                    end
                else
                    keybindRegistry[record] = nil
                end
            end
        end)
    end

    local function localize(key)
        return context.Localize(key)
    end

    local function make(className, properties, parent)
        local object = Instance.new(className)
        for property, value in pairs(properties or {}) do
            local ok, err = pcall(function()
                object[property] = value
            end)
            if not ok then
                warn("[JustHub] Failed to set " .. className .. "." .. tostring(property) .. ": " .. tostring(err))
            end
        end
        if parent then
            object.Parent = parent
        end
        return object
    end

    local function bind(object, property, key)
        Theme:Bind(object, property, key)
        return object
    end

    local function rounded(object, radius)
        make("UICorner", {CornerRadius = UDim.new(0, radius or Theme.Tokens.Geometry.ControlRadius)}, object)
        return object
    end

    local function stroke(object, colorKey, thickness)
        local border = make("UIStroke", {
            ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
            Color = Theme:Get(colorKey or "Color Stroke"),
            Thickness = thickness or 1,
            Transparency = 0,
        }, object)
        bind(border, "Color", colorKey or "Color Stroke")
        return border
    end

    local function textLabel(parent, text, position, size, options)
        options = options or {}
        local label = make("TextLabel", {
            Name = options.Name or "Text",
            Text = tostring(text or ""),
            Position = position or UDim2.new(),
            Size = size or UDim2.new(1, 0, 1, 0),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Font = options.Font or Enum.Font.Gotham,
            TextSize = options.TextSize or Theme.Tokens.Typography.Body,
            TextColor3 = Theme:Get(options.ColorKey or "Color Text"),
            TextXAlignment = options.Align or Enum.TextXAlignment.Left,
            TextYAlignment = options.YAlign or Enum.TextYAlignment.Center,
            TextWrapped = options.Wrapped == true,
            TextTruncate = options.Truncate and Enum.TextTruncate.AtEnd or Enum.TextTruncate.None,
            RichText = false,
            ZIndex = options.ZIndex or 3,
        }, parent)
        bind(label, "TextColor3", options.ColorKey or "Color Text")
        return label
    end

    local function actionButton(parent, text, position, size, options)
        options = options or {}
        local button = make("TextButton", {
            Name = options.Name or "ActionButton",
            Text = tostring(text or ""),
            Position = position or UDim2.new(),
            Size = size or UDim2.new(0, 90, 0, 30),
            BackgroundColor3 = Theme:Get(options.ColorKey or "Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            AutoButtonColor = false,
            Font = options.Font or Enum.Font.GothamSemibold,
            TextSize = options.TextSize or Theme.Tokens.Typography.Small,
            TextColor3 = Theme:Get(options.TextColorKey or "Color Text"),
            ZIndex = options.ZIndex or 4,
        }, parent)
        bind(button, "BackgroundColor3", options.ColorKey or "Color Hub 1")
        bind(button, "TextColor3", options.TextColorKey or "Color Text")
        rounded(button, options.Radius or 7)
        if options.Stroke ~= false then
            stroke(button, options.StrokeKey or "Color Stroke", 1)
        end
        local scope = options.Scope
        if scope then
            scope:Connect(button.MouseEnter, function()
                if not button.Parent then return end
                scope:Tween(button, TweenInfo.new(Theme.Tokens.Animation.Hover, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
                    BackgroundColor3 = Theme:Get(options.HoverKey or "Color Stroke"),
                })
            end)
            scope:Connect(button.MouseLeave, function()
                if not button.Parent then return end
                scope:Tween(button, TweenInfo.new(Theme.Tokens.Animation.Hover, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
                    BackgroundColor3 = Theme:Get(options.ColorKey or "Color Hub 1"),
                })
            end)
        end
        return button
    end

    local function newControlScope(section, frame, label)
        local scope = section.Scope:CreateScope("Control:" .. tostring(label))
        scope:TrackInstance(frame)
        scope:Connect(frame.Destroying, function()
            scope:Destroy()
        end)
        scope:AddCleanup(function()
            for index = #section.Controls, 1, -1 do
                if section.Controls[index] == frame then
                    table.remove(section.Controls, index)
                    break
                end
            end
        end)
        return scope
    end

    local function makeCard(section, title, height, name)
        local frame = make("Frame", {
            Name = name or (tostring(title):gsub("[^%w_%-]", "") .. "Control"),
            Size = UDim2.new(1, -2, 0, height),
            BackgroundColor3 = Theme:Get("Color Hub 2"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ClipsDescendants = true,
            LayoutOrder = #section.Controls + 1,
            ZIndex = 2,
        }, section.Content)
        bind(frame, "BackgroundColor3", "Color Hub 2")
        rounded(frame, Theme.Tokens.Geometry.ControlRadius)
        stroke(frame, "Color Stroke", 1)
        frame:SetAttribute("JustHubSearch", tostring(title):lower())
        table.insert(section.Controls, frame)
        return frame
    end

    local function createHandle(section, scope, title, default, validator, render, callback, controlId)
        local id = controlId or section:MakeControlId(title)
        local handle, err = State:Create(id, default, validator, render, callback, {
            shortName = title,
            tab = section.TabName,
            section = section.SectionName,
        })
        if not handle then
            warn("[JustHub] Unable to register control '" .. id .. "': " .. tostring(err))
            return nil, err
        end
        local registrySetter = context.RegisterBuiltinControl(id, handle, {
            shortName = title,
            defaultValue = Util.Clone(default),
            tab = section.TabName,
            section = section.SectionName,
        })
        scope:AddCleanup(function()
            handle:Destroy()
            Library.ControlRegistry[id] = nil
            Library.Controls[id] = nil
            if registrySetter then
                for alias, setter in pairs(Library.ControlAliases) do
                    if setter == registrySetter then
                        Library.ControlAliases[alias] = nil
                    end
                end
            end
        end)
        return handle
    end

    local function finiteNumber(value)
        return type(value) == "number" and Util.IsFinite(value)
    end

    function Methods:addMenu(name)
        local title = tostring(name or "Menu")
        local frame = make("Frame", {
            Name = title:gsub("[^%w_%-]", "") .. "Menu",
            Size = UDim2.new(1, -2, 0, 36),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            LayoutOrder = #self.Controls + 1,
        }, self.Content)
        bind(frame, "BackgroundColor3", "Color Hub 1")
        rounded(frame, 8)
        stroke(frame, "Color Stroke", 1)
        textLabel(frame, title, UDim2.new(0, 12, 0, 0), UDim2.new(1, -24, 1, 0), {
            Font = Enum.Font.GothamBold,
            TextSize = Theme.Tokens.Typography.Section,
        })
        frame:SetAttribute("JustHubSearch", title:lower())
        table.insert(self.Controls, frame)
        local scope = newControlScope(self, frame, title)
        return frame
    end

    function Methods:addChromaToggle()
        return self:addToggle({
            Name = "Chroma animation",
            Default = Theme.ChromaEnabled,
            Callback = function(enabled)
                Theme:SetChroma(enabled)
            end,
        })
    end

    function Methods:addToggle(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Name or "Toggle")
        local default = options.Default == true
        local callback = type(options.Callback) == "function" and options.Callback or nil
        local frame = makeCard(self, title, 48)
        local scope = newControlScope(self, frame, title)
        textLabel(frame, title, UDim2.new(0, 14, 0, 0), UDim2.new(1, -94, 1, 0), {
            Font = Enum.Font.GothamMedium,
            TextSize = 13,
            Truncate = true,
        })

        local switch = make("Frame", {
            Name = "Switch",
            Size = UDim2.new(0, 46, 0, 24),
            Position = UDim2.new(1, -60, 0.5, -12),
            BackgroundColor3 = default and Theme:Get("Color Theme") or Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 3,
        }, frame)
        bind(switch, "BackgroundColor3", default and "Color Theme" or "Color Hub 1")
        rounded(switch, 12)
        stroke(switch, "Color Stroke", 1)
        local knob = make("Frame", {
            Size = UDim2.new(0, 18, 0, 18),
            Position = default and UDim2.new(1, -21, 0.5, -9) or UDim2.new(0, 3, 0.5, -9),
            BackgroundColor3 = Theme:Get("Color Text"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 4,
        }, switch)
        bind(knob, "BackgroundColor3", "Color Text")
        rounded(knob, 9)
        local hit = make("TextButton", {
            Size = UDim2.new(1, 0, 1, 0),
            BackgroundTransparency = 1,
            Text = "",
            ZIndex = 5,
        }, frame)
        local handle = createHandle(self, scope, title, default,
            function(value) return type(value) == "boolean", "Toggle value must be boolean" end,
            function(value)
                scope:Tween(knob, TweenInfo.new(Theme.Tokens.Animation.Toggle, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
                    Position = value and UDim2.new(1, -21, 0.5, -9) or UDim2.new(0, 3, 0.5, -9),
                })
                local key = value and "Color Theme" or "Color Hub 1"
                Theme:UpdateBinding(switch, "BackgroundColor3", key)
                scope:Tween(switch, TweenInfo.new(Theme.Tokens.Animation.Toggle, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
                    BackgroundColor3 = Theme:Get(key),
                })
                if value then
                    Theme:RegisterChroma(switch, "BackgroundColor3", "Color Theme")
                else
                    Theme:UnregisterChroma(switch, "BackgroundColor3")
                end
            end,
            callback)
        if not handle then return frame end
        scope:Connect(hit.Activated, function()
            handle:Set(not handle:Get())
        end)
        if options.FireOnInit == true and callback then
            task.defer(function()
                if scope:IsAlive() then Util.SafeCall("Initial callback " .. title, callback, default) end
            end)
        end
        return frame
    end

    function Methods:addSlider(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Name or "Slider")
        local minimum = tonumber(options.Min)
        local maximum = tonumber(options.Max)
        local step = tonumber(options.Step or options.Float)
        local default = tonumber(options.Default)
        local callback = type(options.Callback) == "function" and options.Callback or nil
        if not finiteNumber(minimum) then minimum = 0 end
        if not finiteNumber(maximum) or maximum <= minimum then maximum = minimum + 100 end
        if not finiteNumber(step) or step <= 0 then step = 1 end
        if not finiteNumber(default) then default = minimum end

        local precision = 0
        local function countDecimals(number)
            local formatted = string.format("%.8f", number):gsub("0+$", ""):gsub("%.$", "")
            local dot = formatted:find("%.")
            return dot and (#formatted - dot) or 0
        end
        precision = math.max(countDecimals(minimum), countDecimals(maximum), countDecimals(step))
        local function snap(value)
            local bounded = math.clamp(value, minimum, maximum)
            local steps = math.floor(((bounded - minimum) / step) + 0.5)
            local snapped = math.clamp(minimum + steps * step, minimum, maximum)
            return tonumber(string.format("%." .. precision .. "f", snapped))
        end
        local function format(value)
            return precision == 0 and tostring(math.floor(value + 0.5)) or string.format("%." .. precision .. "f", value)
        end
        default = snap(default)

        local frame = makeCard(self, title, 68)
        local scope = newControlScope(self, frame, title)
        textLabel(frame, title, UDim2.new(0, 14, 0, 5), UDim2.new(0.68, -14, 0, 20), {
            Font = Enum.Font.GothamMedium,
            TextSize = 13,
            Truncate = true,
        })
        local valueBox = make("TextBox", {
            Size = UDim2.new(0, 62, 0, 24),
            Position = UDim2.new(1, -76, 0, 4),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            Text = format(default),
            Font = Enum.Font.GothamSemibold,
            TextSize = 12,
            TextColor3 = Theme:Get("Color Text"),
            ClearTextOnFocus = false,
            TextXAlignment = Enum.TextXAlignment.Center,
        }, frame)
        bind(valueBox, "BackgroundColor3", "Color Hub 1")
        bind(valueBox, "TextColor3", "Color Text")
        rounded(valueBox, 6)
        stroke(valueBox)

        local trackButton = make("TextButton", {
            Size = UDim2.new(1, -28, 0, 22),
            Position = UDim2.new(0, 14, 0, 36),
            BackgroundTransparency = 1,
            Text = "",
            AutoButtonColor = false,
            ZIndex = 4,
        }, frame)
        local track = make("Frame", {
            Size = UDim2.new(1, 0, 0, 6),
            Position = UDim2.new(0, 0, 0.5, -3),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 3,
        }, trackButton)
        bind(track, "BackgroundColor3", "Color Hub 1")
        rounded(track, 4)
        local ratio = (default - minimum) / (maximum - minimum)
        local fill = make("Frame", {
            Size = UDim2.new(ratio, 0, 1, 0),
            BackgroundColor3 = Theme:Get("Color Theme"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 4,
        }, track)
        bind(fill, "BackgroundColor3", "Color Theme")
        rounded(fill, 4)
        Theme:RegisterChroma(fill, "BackgroundColor3", "Color Theme")
        local thumb = make("Frame", {
            Size = UDim2.new(0, 16, 0, 16),
            Position = UDim2.new(1, -8, 0.5, -8),
            BackgroundColor3 = Theme:Get("Color Text"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 5,
        }, fill)
        bind(thumb, "BackgroundColor3", "Color Text")
        rounded(thumb, 8)

        local function render(value)
            valueBox.Text = format(value)
            fill.Size = UDim2.new(math.clamp((value - minimum) / (maximum - minimum), 0, 1), 0, 1, 0)
        end
        local handle = createHandle(self, scope, title, default,
            function(value)
                return finiteNumber(value) and value >= minimum and value <= maximum,
                    "Slider value must be finite and inside its configured bounds"
            end,
            render,
            callback)
        if not handle then return frame end

        local dragInput
        local dragConnection, endConnection
        local function valueFromPosition(position)
            local localX = position.X - track.AbsolutePosition.X
            local fraction = math.clamp(localX / math.max(1, track.AbsoluteSize.X), 0, 1)
            return snap(minimum + fraction * (maximum - minimum))
        end
        local function stopDrag()
            if dragConnection then scope:Disconnect(dragConnection); dragConnection = nil end
            if endConnection then scope:Disconnect(endConnection); endConnection = nil end
            dragInput = nil
            handle:EndEdit(true)
        end
        scope:Connect(trackButton.InputBegan, function(input)
            if input.UserInputType ~= Enum.UserInputType.MouseButton1 and input.UserInputType ~= Enum.UserInputType.Touch then
                return
            end
            dragInput = input
            handle:BeginEdit()
            scope:Tween(thumb, TweenInfo.new(0.1), {Size = UDim2.new(0, 20, 0, 20)})
            handle:SetLive(valueFromPosition(input.Position), {skipCallback = true})
            dragConnection = scope:Connect(UserInputService.InputChanged, function(changed)
                if not dragInput then return end
                local isMouse = dragInput.UserInputType == Enum.UserInputType.MouseButton1
                    and changed.UserInputType == Enum.UserInputType.MouseMovement
                local isTouch = dragInput.UserInputType == Enum.UserInputType.Touch and changed == dragInput
                if isMouse or isTouch then
                    handle:SetLive(valueFromPosition(changed.Position), {skipCallback = true})
                end
            end)
            endConnection = scope:Connect(UserInputService.InputEnded, function(ended)
                local isMouse = dragInput and dragInput.UserInputType == Enum.UserInputType.MouseButton1
                    and ended.UserInputType == Enum.UserInputType.MouseButton1
                if dragInput and (ended == dragInput or isMouse) then
                    scope:Tween(thumb, TweenInfo.new(0.1), {Size = UDim2.new(0, 16, 0, 16)})
                    stopDrag()
                end
            end)
        end)
        scope:Connect(UserInputService.WindowFocusReleased, function()
            if dragInput then stopDrag() end
        end)
        scope:Connect(valueBox.FocusLost, function()
            local numeric = tonumber(valueBox.Text)
            if finiteNumber(numeric) then
                handle:Set(snap(numeric))
            else
                valueBox.Text = format(handle:Get())
            end
        end)
        if options.FireOnInit == true and callback then
            task.defer(function()
                if scope:IsAlive() then Util.SafeCall("Initial callback " .. title, callback, default) end
            end)
        end
        return frame
    end

    function Methods:addLabel(options)
        options = type(options) == "string" and {Text = options} or (type(options) == "table" and options or {})
        local title = tostring(options.Text or options.Name or "Label")
        local alignment = tostring(options.Align or "Left")
        local frame = make("Frame", {
            Name = "LabelControl",
            Size = UDim2.new(1, -4, 0, options.Height or 28),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            LayoutOrder = #self.Controls + 1,
        }, self.Content)
        local xAlignment = Enum.TextXAlignment.Left
        if alignment == "Center" then xAlignment = Enum.TextXAlignment.Center end
        if alignment == "Right" then xAlignment = Enum.TextXAlignment.Right end
        local label = textLabel(frame, title, UDim2.new(0, alignment == "Left" and 8 or 0, 0, 0), UDim2.new(1, -16, 1, 0), {
            Align = xAlignment,
            Wrapped = true,
            ColorKey = options.ColorKey or "Color Text",
            TextSize = tonumber(options.TextSize) or 12,
        })
        frame:SetAttribute("JustHubSearch", title:lower())
        table.insert(self.Controls, frame)
        local scope = newControlScope(self, frame, "Label")
        return {
            Frame = frame,
            SetText = function(_, newText)
                if label.Parent then label.Text = tostring(newText or "") end
            end,
            Destroy = function() scope:Destroy() end,
        }
    end

    function Methods:addTextBox(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Name or "Text input")
        local default = type(options.Default) == "string" and options.Default or ""
        local callback = type(options.Callback) == "function" and options.Callback or nil
        local frame = makeCard(self, title, 50)
        local scope = newControlScope(self, frame, title)
        textLabel(frame, title, UDim2.new(0, 12, 0, 0), UDim2.new(0.38, -12, 1, 0), {
            Font = Enum.Font.GothamMedium,
            TextSize = 12,
            Truncate = true,
        })
        local input = make("TextBox", {
            Name = "Input",
            Position = UDim2.new(0.38, 0, 0.5, -16),
            Size = UDim2.new(0.62, -12, 0, 32),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            Text = default,
            PlaceholderText = options.Placeholder or localize("InputHere"),
            Font = Enum.Font.Gotham,
            TextSize = 12,
            TextColor3 = Theme:Get("Color Text"),
            PlaceholderColor3 = Theme:Get("Color Dark Text"),
            ClearTextOnFocus = false,
            TextXAlignment = Enum.TextXAlignment.Left,
        }, frame)
        bind(input, "BackgroundColor3", "Color Hub 1")
        bind(input, "TextColor3", "Color Text")
        bind(input, "PlaceholderColor3", "Color Dark Text")
        rounded(input, 6)
        stroke(input)
        make("UIPadding", {PaddingLeft = UDim.new(0, 8), PaddingRight = UDim.new(0, 8)}, input)
        local handle = createHandle(self, scope, title, default,
            function(value) return type(value) == "string", "TextBox value must be a string" end,
            function(value)
                if input.Text ~= value then input.Text = value end
            end,
            callback)
        if not handle then return frame end
        scope:Connect(input.FocusLost, function()
            handle:Set(input.Text)
        end)
        if options.FireOnInit == true and callback then
            task.defer(function() if scope:IsAlive() then Util.SafeCall("Initial callback " .. title, callback, default) end end)
        end
        return frame
    end

    local function createDropdownShell(section, title, defaultText, height)
        local frame = makeCard(section, title, 44, title:gsub("[^%w_%-]", "") .. "Dropdown")
        frame.ClipsDescendants = true
        local header = make("TextButton", {
            Name = "DropdownHeader",
            Size = UDim2.new(1, 0, 0, 44),
            BackgroundTransparency = 1,
            Text = "",
            AutoButtonColor = false,
            ZIndex = 4,
        }, frame)
        textLabel(header, title, UDim2.new(0, 12, 0, 0), UDim2.new(0.48, -12, 1, 0), {
            Font = Enum.Font.GothamMedium,
            TextSize = 12,
            Truncate = true,
            ZIndex = 5,
        })
        local selected = textLabel(header, defaultText, UDim2.new(0.48, 0, 0, 0), UDim2.new(0.47, -24, 1, 0), {
            Align = Enum.TextXAlignment.Right,
            ColorKey = "Color Dark Text",
            TextSize = 11,
            Truncate = true,
            ZIndex = 5,
        })
        local arrow = textLabel(header, "⌄", UDim2.new(1, -30, 0, 0), UDim2.new(0, 20, 1, 0), {
            Align = Enum.TextXAlignment.Center,
            TextSize = 18,
            ColorKey = "Color Dark Text",
            ZIndex = 5,
        })
        local body = make("Frame", {
            Name = "DropdownBody",
            Position = UDim2.new(0, 0, 0, 44),
            Size = UDim2.new(1, 0, 0, 0),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ClipsDescendants = true,
            ZIndex = 8,
        }, frame)
        bind(body, "BackgroundColor3", "Color Hub 1")
        return frame, header, selected, arrow, body
    end

    local function updateDropdownSize(scope, frame, body, arrow, isOpen, bodyHeight)
        local targetHeight = isOpen and (44 + bodyHeight) or 44
        scope:Tween(frame, TweenInfo.new(Theme.Tokens.Animation.Popup, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
            Size = UDim2.new(1, -2, 0, targetHeight),
        })
        scope:Tween(body, TweenInfo.new(Theme.Tokens.Animation.Popup, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
            Size = UDim2.new(1, 0, 0, isOpen and bodyHeight or 0),
        })
        scope:Tween(arrow, TweenInfo.new(Theme.Tokens.Animation.Popup), {
            Rotation = isOpen and 180 or 0,
        })
    end

    function Methods:addDropdown(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Name or "Dropdown")
        local default = type(options.Default) == "string" and options.Default or ""
        local items = Util.NormalizeStringArray(options.Items)
        local presets = Util.NormalizeStringArray(options.Presets)
        local callback = type(options.Callback) == "function" and options.Callback or nil
        local frame, header, selected, arrow, body = createDropdownShell(self, title, default ~= "" and default or localize("Select"))
        local scope = newControlScope(self, frame, title)
        local search = make("TextBox", {
            Position = UDim2.new(0, 8, 0, 8),
            Size = UDim2.new(1, -16, 0, 28),
            BackgroundColor3 = Theme:Get("Color Hub 2"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            Text = "",
            PlaceholderText = localize("SearchOptions"),
            Font = Enum.Font.Gotham,
            TextSize = 11,
            TextColor3 = Theme:Get("Color Text"),
            PlaceholderColor3 = Theme:Get("Color Dark Text"),
            ClearTextOnFocus = false,
            ZIndex = 10,
        }, body)
        bind(search, "BackgroundColor3", "Color Hub 2")
        bind(search, "TextColor3", "Color Text")
        bind(search, "PlaceholderColor3", "Color Dark Text")
        rounded(search, 6)
        stroke(search)
        local list = make("ScrollingFrame", {
            Position = UDim2.new(0, 8, 0, 42),
            Size = UDim2.new(1, -16, 1, -48),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            ScrollBarThickness = 3,
            AutomaticCanvasSize = Enum.AutomaticSize.Y,
            CanvasSize = UDim2.new(),
            ZIndex = 9,
        }, body)
        bind(list, "ScrollBarImageColor3", "Color Stroke")
        make("UIListLayout", {
            Padding = UDim.new(0, 4),
            SortOrder = Enum.SortOrder.LayoutOrder,
        }, list)

        local isOpen = false
        local records = {}
        local handle
        local function renderFilter(term)
            local lower = tostring(term or ""):lower()
            for _, record in ipairs(records) do
                record.Button.Visible = lower == "" or record.Display:lower():find(lower, 1, true) ~= nil
            end
        end
        local function displayFor(value)
            for _, record in ipairs(records) do
                if record.Value == value then return record.Display end
            end
            return tostring(value or "")
        end
        local function rebuild(newItems)
            for _, record in ipairs(records) do
                record.Scope:Destroy()
            end
            table.clear(records)
            local function addOption(value, isPreset)
                local display = isPreset and ("★ " .. value) or value
                local rowScope = scope:CreateScope("DropdownItem")
                local button = make("TextButton", {
                    Size = UDim2.new(1, 0, 0, 30),
                    BackgroundColor3 = Theme:Get("Color Hub 2"),
                    BackgroundTransparency = 0,
                    BorderSizePixel = 0,
                    Text = "  " .. display,
                    Font = Enum.Font.Gotham,
                    TextSize = 11,
                    TextColor3 = Theme:Get(isPreset and "Color Theme" or "Color Text"),
                    TextXAlignment = Enum.TextXAlignment.Left,
                    AutoButtonColor = false,
                    ZIndex = 10,
                }, list)
                rowScope:TrackInstance(button)
                bind(button, "BackgroundColor3", "Color Hub 2")
                bind(button, "TextColor3", isPreset and "Color Theme" or "Color Text")
                rounded(button, 5)
                rowScope:Connect(button.Activated, function()
                    handle:Set(value)
                    selected.Text = display
                    isOpen = false
                    updateDropdownSize(scope, frame, body, arrow, false, 150)
                    search.Text = ""
                end)
                rowScope:Connect(button.MouseEnter, function()
                    if button.Parent then button.BackgroundColor3 = Theme:Get("Color Stroke") end
                end)
                rowScope:Connect(button.MouseLeave, function()
                    if button.Parent then button.BackgroundColor3 = Theme:Get("Color Hub 2") end
                end)
                table.insert(records, {Value = value, Display = display, Button = button, Scope = rowScope})
            end
            for _, preset in ipairs(presets) do addOption(preset, true) end
            for _, item in ipairs(Util.NormalizeStringArray(newItems)) do addOption(item, false) end
            renderFilter(search.Text)
            selected.Text = handle and handle:Get() ~= "" and displayFor(handle:Get()) or localize("Select")
        end

        handle = createHandle(self, scope, title, default,
            function(value) return type(value) == "string", "Dropdown value must be a string" end,
            function(value)
                if value == "" then
                    selected.Text = localize("Select")
                else
                    selected.Text = displayFor(value)
                end
            end,
            callback)
        if not handle then return frame end

        rebuild(items)
        scope:Connect(search:GetPropertyChangedSignal("Text"), function()
            renderFilter(search.Text)
        end)
        scope:Connect(header.Activated, function()
            isOpen = not isOpen
            updateDropdownSize(scope, frame, body, arrow, isOpen, 154)
            if isOpen then
                search.Text = ""
                renderFilter("")
            end
        end)

        return {
            Frame = frame,
            Refresh = function(_, newList)
                items = Util.NormalizeStringArray(newList)
                rebuild(items)
            end,
            Clear = function()
                handle:Set("")
                isOpen = false
                search.Text = ""
                updateDropdownSize(scope, frame, body, arrow, false, 154)
            end,
            GetValue = function() return handle:Get() end,
            SetValue = function(_, value) return handle:Set(value) end,
            Destroy = function() scope:Destroy() end,
        }
    end

    function Methods:addMultiDropdown(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Name or "Multi select")
        local default = Util.NormalizeStringArray(options.Default)
        local items = Util.NormalizeStringArray(options.Items)
        local presets = Util.NormalizeStringArray(options.Presets)
        local callback = type(options.Callback) == "function" and options.Callback or nil
        local defaultText = #default > 0 and table.concat(default, ", ") or localize("Select")
        local frame, header, selected, arrow, body = createDropdownShell(self, title, defaultText)
        local scope = newControlScope(self, frame, title)
        local toolbar = make("Frame", {
            Position = UDim2.new(0, 8, 0, 7),
            Size = UDim2.new(1, -16, 0, 28),
            BackgroundTransparency = 1,
            ZIndex = 10,
        }, body)
        local selectAll = actionButton(toolbar, localize("SelectAll"), UDim2.new(0, 0, 0, 0), UDim2.new(0, 74, 1, 0), {
            ColorKey = "Color Theme", TextSize = 10, Stroke = false, Scope = scope,
        })
        local clearAll = actionButton(toolbar, localize("ClearAll"), UDim2.new(0, 80, 0, 0), UDim2.new(0, 70, 1, 0), {
            ColorKey = "Color Hub 2", TextSize = 10, Scope = scope,
        })
        local search = make("TextBox", {
            Position = UDim2.new(0, 156, 0, 0),
            Size = UDim2.new(1, -156, 1, 0),
            BackgroundColor3 = Theme:Get("Color Hub 2"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            Text = "",
            PlaceholderText = localize("SearchOptions"),
            Font = Enum.Font.Gotham,
            TextSize = 10,
            TextColor3 = Theme:Get("Color Text"),
            PlaceholderColor3 = Theme:Get("Color Dark Text"),
            ClearTextOnFocus = false,
            ZIndex = 10,
        }, toolbar)
        bind(search, "BackgroundColor3", "Color Hub 2")
        bind(search, "TextColor3", "Color Text")
        bind(search, "PlaceholderColor3", "Color Dark Text")
        rounded(search, 5)
        stroke(search)
        local list = make("ScrollingFrame", {
            Position = UDim2.new(0, 8, 0, 42),
            Size = UDim2.new(1, -16, 1, -48),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            ScrollBarThickness = 3,
            AutomaticCanvasSize = Enum.AutomaticSize.Y,
            CanvasSize = UDim2.new(),
            ZIndex = 9,
        }, body)
        bind(list, "ScrollBarImageColor3", "Color Stroke")
        make("UIListLayout", {Padding = UDim.new(0, 4), SortOrder = Enum.SortOrder.LayoutOrder}, list)

        local selectedSet = {}
        for _, item in ipairs(default) do selectedSet[item] = true end
        local records = {}
        local handle
        local function sortedSelection()
            local result = {}
            for item, active in pairs(selectedSet) do
                if active then table.insert(result, item) end
            end
            table.sort(result)
            return result
        end
        local function updateLabel()
            local selectedItems = sortedSelection()
            selected.Text = #selectedItems > 0 and table.concat(selectedItems, ", ") or localize("Select")
        end
        local function renderFilter(term)
            local lower = tostring(term or ""):lower()
            for _, record in ipairs(records) do
                local visible = lower == "" or record.Display:lower():find(lower, 1, true) ~= nil
                record.Button.Visible = visible
                local selectedValue = selectedSet[record.Value] == true
                local colorKey = selectedValue and "Color Theme" or "Color Hub 1"
                record.Check.BackgroundColor3 = Theme:Get(colorKey)
                Theme:UpdateBinding(record.Check, "BackgroundColor3", colorKey)
            end
        end
        local function updateState()
            local values = sortedSelection()
            updateLabel()
            renderFilter(search.Text)
            handle:Set(values)
        end
        local function rebuild(newList)
            for _, record in ipairs(records) do record.Scope:Destroy() end
            table.clear(records)
            local function addOption(value, isPreset)
                local rowScope = scope:CreateScope("MultiDropdownItem")
                local display = isPreset and ("★ " .. value) or value
                local button = make("TextButton", {
                    Size = UDim2.new(1, 0, 0, 30),
                    BackgroundColor3 = Theme:Get("Color Hub 2"),
                    BackgroundTransparency = 0,
                    BorderSizePixel = 0,
                    Text = "  " .. display,
                    Font = Enum.Font.Gotham,
                    TextSize = 11,
                    TextColor3 = Theme:Get(isPreset and "Color Theme" or "Color Text"),
                    TextXAlignment = Enum.TextXAlignment.Left,
                    AutoButtonColor = false,
                    ZIndex = 10,
                }, list)
                rowScope:TrackInstance(button)
                bind(button, "BackgroundColor3", "Color Hub 2")
                bind(button, "TextColor3", isPreset and "Color Theme" or "Color Text")
                rounded(button, 5)
                local check = make("Frame", {
                    Size = UDim2.new(0, 14, 0, 14),
                    Position = UDim2.new(1, -24, 0.5, -7),
                    BackgroundColor3 = selectedSet[value] and Theme:Get("Color Theme") or Theme:Get("Color Hub 1"),
                    BackgroundTransparency = 0,
                    BorderSizePixel = 0,
                    ZIndex = 11,
                }, button)
                bind(check, "BackgroundColor3", selectedSet[value] and "Color Theme" or "Color Hub 1")
                rounded(check, 4)
                stroke(check)
                rowScope:Connect(button.Activated, function()
                    selectedSet[value] = not selectedSet[value]
                    updateState()
                end)
                table.insert(records, {Value = value, Display = display, Button = button, Check = check, Scope = rowScope})
            end
            for _, preset in ipairs(presets) do addOption(preset, true) end
            for _, item in ipairs(Util.NormalizeStringArray(newList)) do addOption(item, false) end
            renderFilter(search.Text)
            updateLabel()
        end

        handle = createHandle(self, scope, title, default,
            function(value)
                if not Util.IsDenseArray(value) then
                    return false, "MultiDropdown value must be a dense array of strings"
                end
                for _, item in ipairs(value) do
                    if type(item) ~= "string" then return false, "MultiDropdown values must be strings" end
                end
                return true
            end,
            function(value)
                table.clear(selectedSet)
                for _, item in ipairs(value) do selectedSet[item] = true end
                updateLabel()
                renderFilter(search.Text)
            end,
            callback)
        if not handle then return frame end

        rebuild(items)
        scope:Connect(search:GetPropertyChangedSignal("Text"), function() renderFilter(search.Text) end)
        scope:Connect(selectAll.Activated, function()
            for _, item in ipairs(items) do selectedSet[item] = true end
            for _, item in ipairs(presets) do selectedSet[item] = true end
            updateState()
        end)
        scope:Connect(clearAll.Activated, function()
            table.clear(selectedSet)
            updateState()
        end)
        local isOpen = false
        scope:Connect(header.Activated, function()
            isOpen = not isOpen
            updateDropdownSize(scope, frame, body, arrow, isOpen, 158)
            if isOpen then search.Text = ""; renderFilter("") end
        end)

        return {
            Frame = frame,
            Refresh = function(_, newList)
                items = Util.NormalizeStringArray(newList)
                rebuild(items)
            end,
            GetValue = function() return handle:Get() end,
            SetValue = function(_, value) return handle:Set(value) end,
            Destroy = function() scope:Destroy() end,
        }
    end

    function Methods:addColorPicker(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Name or "Color")
        local default = typeof(options.Default) == "Color3" and options.Default or Color3.fromRGB(80, 200, 160)
        local callback = type(options.Callback) == "function" and options.Callback or nil
        local frame = makeCard(self, title, 96)
        local scope = newControlScope(self, frame, title)
        textLabel(frame, title, UDim2.new(0, 12, 0, 4), UDim2.new(0.6, -12, 0, 22), {
            Font = Enum.Font.GothamMedium,
            TextSize = 12,
        })
        local preview = make("Frame", {
            Size = UDim2.new(0, 58, 0, 24),
            Position = UDim2.new(1, -72, 0, 4),
            BackgroundColor3 = default,
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
        }, frame)
        rounded(preview, 5)
        stroke(preview)
        local presets = {
            Color3.fromRGB(239, 68, 68), Color3.fromRGB(34, 197, 94),
            Color3.fromRGB(59, 130, 246), Color3.fromRGB(234, 179, 8),
            Color3.fromRGB(168, 85, 247), Color3.fromRGB(6, 182, 212),
            Color3.fromRGB(255, 255, 255), Color3.fromRGB(24, 24, 27),
        }
        local presetRow = make("Frame", {
            Position = UDim2.new(0, 12, 0, 34),
            Size = UDim2.new(1, -24, 0, 22),
            BackgroundTransparency = 1,
        }, frame)
        make("UIListLayout", {FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 8)}, presetRow)
        local rBox, gBox, bBox, hexBox
        local function sync(color)
            preview.BackgroundColor3 = color
            if rBox then
                rBox.Text = tostring(math.floor(color.R * 255 + 0.5))
                gBox.Text = tostring(math.floor(color.G * 255 + 0.5))
                bBox.Text = tostring(math.floor(color.B * 255 + 0.5))
                hexBox.Text = "#" .. color:ToHex():upper()
            end
        end
        local handle = createHandle(self, scope, title, default,
            function(value) return typeof(value) == "Color3", "ColorPicker value must be Color3" end,
            sync,
            callback)
        if not handle then return frame end

        for _, color in ipairs(presets) do
            local swatch = make("TextButton", {
                Size = UDim2.new(0, 20, 0, 20),
                BackgroundColor3 = color,
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                Text = "",
                AutoButtonColor = false,
            }, presetRow)
            rounded(swatch, 10)
            stroke(swatch, "Color Stroke", 1)
            scope:Connect(swatch.Activated, function() handle:Set(color) end)
        end

        local inputRow = make("Frame", {
            Position = UDim2.new(0, 12, 0, 63),
            Size = UDim2.new(1, -24, 0, 24),
            BackgroundTransparency = 1,
        }, frame)
        make("UIListLayout", {FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 6)}, inputRow)
        local function colorBox(name, initial, width, textColor)
            local box = make("TextBox", {
                Name = name,
                Size = UDim2.new(0, width, 1, 0),
                BackgroundColor3 = Theme:Get("Color Hub 1"),
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                Text = initial,
                Font = Enum.Font.GothamMedium,
                TextSize = 10,
                TextColor3 = textColor or Theme:Get("Color Text"),
                ClearTextOnFocus = false,
                TextXAlignment = Enum.TextXAlignment.Center,
            }, inputRow)
            bind(box, "BackgroundColor3", "Color Hub 1")
            if not textColor then bind(box, "TextColor3", "Color Text") end
            rounded(box, 4)
            stroke(box)
            return box
        end
        rBox = colorBox("Red", "", 38, Color3.fromRGB(255, 115, 115))
        gBox = colorBox("Green", "", 38, Color3.fromRGB(115, 230, 140))
        bBox = colorBox("Blue", "", 38, Color3.fromRGB(115, 165, 255))
        hexBox = colorBox("Hex", "", 82)
        sync(default)
        local function commitRgb()
            local red, green, blue = tonumber(rBox.Text), tonumber(gBox.Text), tonumber(bBox.Text)
            if not (finiteNumber(red) and finiteNumber(green) and finiteNumber(blue)) then
                sync(handle:Get())
                return
            end
            handle:Set(Color3.fromRGB(
                math.floor(math.clamp(red, 0, 255) + 0.5),
                math.floor(math.clamp(green, 0, 255) + 0.5),
                math.floor(math.clamp(blue, 0, 255) + 0.5)
            ))
        end
        local function commitHex()
            local hex = hexBox.Text:gsub("#", "")
            local ok, color = pcall(Color3.fromHex, hex)
            if ok and typeof(color) == "Color3" then
                handle:Set(color)
            else
                sync(handle:Get())
            end
        end
        scope:Connect(rBox.FocusLost, commitRgb)
        scope:Connect(gBox.FocusLost, commitRgb)
        scope:Connect(bBox.FocusLost, commitRgb)
        scope:Connect(hexBox.FocusLost, commitHex)
        return frame
    end

    function Methods:addScriptBox(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Name or "Script editor")
        local default = type(options.Default) == "string" and options.Default or ""
        local callback = type(options.Callback) == "function" and options.Callback or function() end
        local frame = makeCard(self, title, 128)
        local scope = newControlScope(self, frame, title)
        textLabel(frame, title, UDim2.new(0, 12, 0, 5), UDim2.new(1, -24, 0, 20), {
            Font = Enum.Font.GothamMedium,
            TextSize = 12,
        })
        local input = make("TextBox", {
            Position = UDim2.new(0, 12, 0, 30),
            Size = UDim2.new(1, -96, 0, 88),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            Text = default,
            PlaceholderText = options.Placeholder or localize("PasteHere"),
            Font = Enum.Font.Code,
            TextSize = 11,
            TextColor3 = Theme:Get("Color Text"),
            ClearTextOnFocus = false,
            MultiLine = true,
            TextWrapped = false,
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Top,
        }, frame)
        bind(input, "BackgroundColor3", "Color Hub 1")
        bind(input, "TextColor3", "Color Text")
        rounded(input, 6)
        stroke(input)
        make("UIPadding", {PaddingLeft = UDim.new(0, 8), PaddingRight = UDim.new(0, 8), PaddingTop = UDim.new(0, 6)}, input)
        local runButton = actionButton(frame, options.ButtonText or localize("Run"), UDim2.new(1, -76, 0, 54), UDim2.new(0, 64, 0, 34), {
            ColorKey = "Color Theme", TextColorKey = "Color Hub 1", Scope = scope,
        })
        local handle = createHandle(self, scope, title, default,
            function(value) return type(value) == "string", "ScriptBox value must be a string" end,
            function(value) if input.Text ~= value then input.Text = value end end,
            nil)
        if not handle then return frame end
        scope:Connect(input.FocusLost, function() handle:Set(input.Text, {skipCallback = true}) end)
        scope:Connect(runButton.Activated, function()
            Util.SafeCall("ScriptBox callback " .. title, callback, input.Text)
        end)
        return frame
    end

    function Methods:addBind(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Name or "Keybind")
        local default = options.Default or "RightShift"
        if typeof(default) == "EnumItem" and default.EnumType == Enum.KeyCode then
            default = default.Name
        elseif type(default) ~= "string" then
            default = "RightShift"
        end
        local callback = type(options.Callback) == "function" and options.Callback or nil
        local frame = makeCard(self, title, 48)
        local scope = newControlScope(self, frame, title)
        textLabel(frame, title, UDim2.new(0, 12, 0, 0), UDim2.new(0.55, -12, 1, 0), {
            Font = Enum.Font.GothamMedium,
            TextSize = 12,
            Truncate = true,
        })
        local input = make("TextBox", {
            Position = UDim2.new(0.58, 0, 0.5, -15),
            Size = UDim2.new(0.42, -12, 0, 30),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            Text = default,
            Font = Enum.Font.GothamSemibold,
            TextSize = 11,
            TextColor3 = Theme:Get("Color Text"),
            ClearTextOnFocus = false,
            TextXAlignment = Enum.TextXAlignment.Center,
        }, frame)
        bind(input, "BackgroundColor3", "Color Hub 1")
        bind(input, "TextColor3", "Color Text")
        rounded(input, 6)
        stroke(input)

        local blacklist = {
            W = true, A = true, S = true, D = true, Space = true,
            Escape = true, Tab = true, Backspace = true, Return = true,
            Unknown = true,
        }
        local function normalizeKey(value)
            local key = Enum.KeyCode[value]
            if not key or blacklist[key.Name] then return "None" end
            return key.Name
        end
        local handle = createHandle(self, scope, title, normalizeKey(default),
            function(value)
                return type(value) == "string" and (value == "None" or normalizeKey(value) == value),
                    "Keybind must be a valid, supported key name"
            end,
            function(value) input.Text = value end,
            nil)
        if not handle then return frame end
        local keybindRecord = {
            Title = title,
            Input = input,
            Handle = handle,
            Scope = scope,
            Callback = callback,
            Normalize = normalizeKey,
            Capturing = false,
        }
        keybindRegistry[keybindRecord] = true
        scope:AddCleanup(function()
            keybindRegistry[keybindRecord] = nil
        end)
        scope:Connect(input.Focused, function()
            keybindRecord.Capturing = true
            input.Text = localize("PressKey")
        end)
        scope:Connect(input.FocusLost, function()
            keybindRecord.Capturing = false
            input.Text = handle:Get()
        end)
        return frame
    end

    function Methods:addButton(options)
        options = type(options) == "table" and options or {}
        local title = tostring(options.Name or "Action")
        local buttonText = tostring(options.ButtonText or "Run")
        local callback = type(options.Callback) == "function" and options.Callback or function() end
        local frame = makeCard(self, title, 48)
        local scope = newControlScope(self, frame, title)
        textLabel(frame, title, UDim2.new(0, 12, 0, 0), UDim2.new(0.56, -12, 1, 0), {
            Font = Enum.Font.GothamMedium,
            TextSize = 12,
            Truncate = true,
        })
        local button = actionButton(frame, buttonText, UDim2.new(0.56, 0, 0.5, -15), UDim2.new(0.44, -12, 0, 30), {
            ColorKey = "Color Theme",
            TextColorKey = "Color Hub 1",
            Scope = scope,
            TextSize = 11,
        })
        scope:Connect(button.Activated, function()
            Util.SafeCall("Button callback " .. title, callback)
        end)
        return frame
    end

    function Methods:addConfigManager()
        local title = "Configuration profiles"
        local frame = makeCard(self, title, 110, "ConfigManagerControl")
        local scope = newControlScope(self, frame, title)
        local input = make("TextBox", {
            Position = UDim2.new(0, 10, 0, 10),
            Size = UDim2.new(1, -20, 0, 30),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            Text = "DefaultConfig",
            PlaceholderText = localize("ConfigName"),
            Font = Enum.Font.Gotham,
            TextSize = 11,
            TextColor3 = Theme:Get("Color Text"),
            ClearTextOnFocus = false,
        }, frame)
        bind(input, "BackgroundColor3", "Color Hub 1")
        bind(input, "TextColor3", "Color Text")
        rounded(input, 6)
        stroke(input)
        local saveButton = actionButton(frame, localize("SaveProfile"), UDim2.new(0, 10, 0, 50), UDim2.new(0.32, -8, 0, 28), {
            ColorKey = "Color Theme", TextColorKey = "Color Hub 1", Scope = scope, TextSize = 10,
        })
        local loadButton = actionButton(frame, localize("LoadProfile"), UDim2.new(0.34, 0, 0, 50), UDim2.new(0.32, -8, 0, 28), {
            ColorKey = "Color Hub 1", Scope = scope, TextSize = 10,
        })
        local deleteButton = actionButton(frame, localize("DeleteProfile"), UDim2.new(0.68, -2, 0, 50), UDim2.new(0.32, -8, 0, 28), {
            ColorKey = "Color Stroke", Scope = scope, TextSize = 10,
        })
        scope:Connect(saveButton.Activated, function()
            local ok, err = Library:SaveConfig(input.Text)
            if not ok then Library:Notify({Title = "Save Config", Message = tostring(err), Duration = 4}) end
        end)
        scope:Connect(loadButton.Activated, function()
            local ok, result = Library:LoadConfig(input.Text)
            if not ok then Library:Notify({Title = "Load Config", Message = tostring(result), Duration = 4}) end
        end)
        scope:Connect(deleteButton.Activated, function()
            local ok, result = Library.ConfigManager:Delete(input.Text)
            Library:Notify({Title = "Delete Config", Message = ok and ("Deleted: " .. tostring(result)) or tostring(result), Duration = 3})
        end)
        return frame
    end

    Methods.AddMenu = Methods.addMenu
    Methods.AddChromaToggle = Methods.addChromaToggle
    Methods.AddToggle = Methods.addToggle
    Methods.AddSlider = Methods.addSlider
    Methods.AddLabel = Methods.addLabel
    Methods.AddTextBox = Methods.addTextBox
    Methods.AddDropdown = Methods.addDropdown
    Methods.AddMultiDropdown = Methods.addMultiDropdown
    Methods.AddColorPicker = Methods.addColorPicker
    Methods.AddScriptBox = Methods.addScriptBox
    Methods.AddBind = Methods.addBind
    Methods.AddButton = Methods.addButton
    Methods.AddConfigManager = Methods.addConfigManager

    return Methods
end
