return function(context)
    local Instance = context.Instance
    local Enum = context.Enum
    local Players = context.Players
    local UserInputService = context.UserInputService
    local Theme = context.Theme
    local RootScope = context.RootScope
    local Components = context.Components
    local Library = context.Library
    local TweenInfo = context.TweenInfo
    local Util = context.Util

    local Window = {}
    Window.__index = Window

    local function make(className, properties, parent)
        local object = Instance.new(className)
        for property, value in pairs(properties or {}) do
            local ok, err = pcall(function()
                object[property] = value
            end)
            if not ok then
                warn("[JustHub] Window property error " .. className .. "." .. tostring(property) .. ": " .. tostring(err))
            end
        end
        if parent then object.Parent = parent end
        return object
    end

    local function bind(object, property, key)
        Theme:Bind(object, property, key)
        return object
    end

    local function corner(object, radius)
        make("UICorner", {CornerRadius = UDim.new(0, radius)}, object)
    end

    local function border(object, thickness)
        local stroke = make("UIStroke", {
            Color = Theme:Get("Color Stroke"),
            Thickness = thickness or 1,
            Transparency = 0,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
        }, object)
        bind(stroke, "Color", "Color Stroke")
        return stroke
    end

    local function makeText(parent, text, position, size, options)
        options = options or {}
        local label = make("TextLabel", {
            Name = options.Name or "Text",
            Text = tostring(text or ""),
            Position = position,
            Size = size,
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Font = options.Font or Enum.Font.Gotham,
            TextSize = options.TextSize or 12,
            TextColor3 = Theme:Get(options.ColorKey or "Color Text"),
            TextXAlignment = options.Align or Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Center,
            TextWrapped = options.Wrapped == true,
            TextTruncate = options.Truncate and Enum.TextTruncate.AtEnd or Enum.TextTruncate.None,
            ZIndex = options.ZIndex or 3,
        }, parent)
        bind(label, "TextColor3", options.ColorKey or "Color Text")
        return label
    end

    local function makeHeaderButton(parent, name, glyph, colorKey, order)
        local button = make("TextButton", {
            Name = name,
            Text = glyph,
            Size = UDim2.new(0, 28, 0, 28),
            LayoutOrder = order,
            BackgroundColor3 = Theme:Get(colorKey or "Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            AutoButtonColor = false,
            Font = Enum.Font.GothamBold,
            TextSize = 13,
            TextColor3 = Theme:Get("Color Text"),
            ZIndex = 5,
        }, parent)
        bind(button, "BackgroundColor3", colorKey or "Color Hub 1")
        bind(button, "TextColor3", "Color Text")
        corner(button, 7)
        border(button)
        return button
    end

    local function getViewport()
        local camera = workspace.CurrentCamera
        if camera then
            return camera.ViewportSize
        end
        return Vector2.new(1280, 720)
    end

    function Window.new(options)
        local createdScope
        local buildOk, builtWindow = xpcall(function()
        options = type(options) == "table" and options or {}
        local player = Players.LocalPlayer
        if not player then
            error("JustHub requires a client context with Players.LocalPlayer", 2)
        end

        local windowScope = RootScope:CreateScope("Window")
        createdScope = windowScope
        local parent = options.Parent
        if not parent then
            parent = player:WaitForChild("PlayerGui")
            if options.UseCoreGui == true then
                local ok, core = pcall(function() return game:GetService("CoreGui") end)
                if ok and core then
                    local probe = Instance.new("ScreenGui")
                    local parentOk = pcall(function() probe.Parent = core end)
                    Util.SafeDestroy(probe)
                    if parentOk then parent = core end
                end
            end
        end

        for _, child in ipairs(parent:GetChildren()) do
            if child.Name == "JustHub" or child.Name == "JustHubLoadingScreen" or child.Name == "JustHubShowUI" then
                local cleanup = child:FindFirstChild("__JustHubCleanup")
                if cleanup and cleanup:IsA("BindableFunction") then
                    pcall(function() cleanup:Invoke() end)
                end
                Util.SafeDestroy(child)
            end
        end

        local screen = make("ScreenGui", {
            Name = "JustHub",
            ResetOnSpawn = false,
            IgnoreGuiInset = true,
            ZIndexBehavior = Enum.ZIndexBehavior.Global,
            DisplayOrder = options.DisplayOrder or 900,
        }, parent)
        windowScope:TrackInstance(screen)
        Library.ScreenGui = screen
        Library.ScreenGuis = {screen}

        local bridge = make("BindableFunction", {Name = "__JustHubCleanup"}, screen)
        bridge.OnInvoke = function()
            Library:Destroy()
            return true
        end

        local viewport = getViewport()
        local desiredWidth = tonumber(options.Width) or Library.Save.UISize[1] or 760
        local desiredHeight = tonumber(options.Height) or Library.Save.UISize[2] or 520
        local maxInitialWidth = math.max(240, viewport.X - 24)
        local maxInitialHeight = math.max(200, viewport.Y - 24)
        local minInitialWidth = math.min(Theme.Tokens.Dimensions.MinWidth, maxInitialWidth)
        local minInitialHeight = math.min(Theme.Tokens.Dimensions.MinHeight, maxInitialHeight)
        local width = math.clamp(desiredWidth, minInitialWidth, maxInitialWidth)
        local height = math.clamp(desiredHeight, minInitialHeight, maxInitialHeight)

        local main = make("Frame", {
            Name = "MainFrame",
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromOffset(width, height),
            BackgroundColor3 = Theme:Get("Color Hub 2"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ClipsDescendants = true,
            Active = true,
            ZIndex = 1,
        }, screen)
        bind(main, "BackgroundColor3", "Color Hub 2")
        corner(main, Theme.Tokens.Geometry.WindowRadius)
        border(main, 1)

        local header = make("Frame", {
            Name = "TopBar",
            Size = UDim2.new(1, 0, 0, Theme.Tokens.Dimensions.Header),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            Active = true,
            ZIndex = 2,
        }, main)
        bind(header, "BackgroundColor3", "Color Hub 1")
        local title = makeText(header, options.Name or "JustHub", UDim2.new(0, 20, 0, 7), UDim2.new(1, -180, 0, 22), {
            Font = Enum.Font.GothamBold,
            TextSize = 17,
            Truncate = true,
        })
        local subtitle = makeText(header, options.SubTitle or "MODULAR INTERFACE FRAMEWORK", UDim2.new(0, 20, 0, 30), UDim2.new(1, -180, 0, 16), {
            Font = Enum.Font.GothamMedium,
            TextSize = 9,
            ColorKey = "Color Dark Text",
            Truncate = true,
        })
        local headerButtons = make("Frame", {
            Name = "HeaderActions",
            AnchorPoint = Vector2.new(1, 0.5),
            Position = UDim2.new(1, -14, 0.5, 0),
            Size = UDim2.new(0, 146, 0, 30),
            BackgroundTransparency = 1,
            ZIndex = 4,
        }, header)
        make("UIListLayout", {
            FillDirection = Enum.FillDirection.Horizontal,
            HorizontalAlignment = Enum.HorizontalAlignment.Right,
            VerticalAlignment = Enum.VerticalAlignment.Center,
            Padding = UDim.new(0, 6),
            SortOrder = Enum.SortOrder.LayoutOrder,
        }, headerButtons)
        local minimizeButton = makeHeaderButton(headerButtons, "MinimizeButton", "−", "Color Hub 2", 1)
        local maximizeButton = makeHeaderButton(headerButtons, "MaximizeButton", "□", "Color Hub 2", 2)
        local lockButton = makeHeaderButton(headerButtons, "LockButton", "U", "Color Hub 2", 3)
        local closeButton = makeHeaderButton(headerButtons, "CloseButton", "×", "Color Stroke", 4)

        local body = make("Frame", {
            Name = "Body",
            Position = UDim2.new(0, 0, 0, Theme.Tokens.Dimensions.Header),
            Size = UDim2.new(1, 0, 1, -82),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            ZIndex = 2,
        }, main)

        local sideWidth = tonumber(options.SidebarWidth) or tonumber(Library.Save.TabSize) or Theme.Tokens.Dimensions.Sidebar
        local sidebar = make("Frame", {
            Name = "Sidebar",
            Position = UDim2.new(0, 14, 0, 12),
            Size = UDim2.new(0, sideWidth, 1, -24),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 2,
        }, body)
        bind(sidebar, "BackgroundColor3", "Color Hub 1")
        corner(sidebar, Theme.Tokens.Geometry.SidebarRadius)
        border(sidebar)
        local sidebarTitle = makeText(sidebar, "JUSTHUB", UDim2.new(0, 14, 0, 14), UDim2.new(1, -28, 0, 24), {
            Font = Enum.Font.GothamBlack,
            TextSize = 15,
        })
        local sidebarSubtitle = makeText(sidebar, "CONTROL CENTER", UDim2.new(0, 14, 0, 36), UDim2.new(1, -28, 0, 16), {
            Font = Enum.Font.GothamMedium,
            TextSize = 8,
            ColorKey = "Color Dark Text",
        })
        local playerCard = make("Frame", {
            Position = UDim2.new(0, 10, 0, 64),
            Size = UDim2.new(1, -20, 0, 44),
            BackgroundColor3 = Theme:Get("Color Hub 2"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
        }, sidebar)
        bind(playerCard, "BackgroundColor3", "Color Hub 2")
        corner(playerCard, 7)
        local playerName = makeText(playerCard, player.DisplayName or player.Name, UDim2.new(0, 9, 0, 0), UDim2.new(1, -18, 1, 0), {
            Font = Enum.Font.GothamSemibold,
            TextSize = 11,
            Truncate = true,
        })
        local tabList = make("ScrollingFrame", {
            Name = "TabList",
            Position = UDim2.new(0, 8, 0, 118),
            Size = UDim2.new(1, -16, 1, -130),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            ScrollBarThickness = 2,
            AutomaticCanvasSize = Enum.AutomaticSize.Y,
            CanvasSize = UDim2.new(),
            ZIndex = 3,
        }, sidebar)
        bind(tabList, "ScrollBarImageColor3", "Color Stroke")
        make("UIListLayout", {
            Padding = UDim.new(0, 6),
            SortOrder = Enum.SortOrder.LayoutOrder,
        }, tabList)

        local content = make("Frame", {
            Name = "ContentContainer",
            Position = UDim2.new(0, sideWidth + 28, 0, 12),
            Size = UDim2.new(1, -(sideWidth + 42), 1, -24),
            BackgroundColor3 = Theme:Get("Color Hub 1"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ClipsDescendants = true,
            ZIndex = 2,
        }, body)
        bind(content, "BackgroundColor3", "Color Hub 1")
        corner(content, 10)
        border(content)

        local searchFrame = make("Frame", {
            Name = "SearchFrame",
            Position = UDim2.new(0, 12, 0, 12),
            Size = UDim2.new(1, -24, 0, 36),
            BackgroundColor3 = Theme:Get("Color Hub 2"),
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 3,
        }, content)
        bind(searchFrame, "BackgroundColor3", "Color Hub 2")
        corner(searchFrame, 7)
        border(searchFrame)
        makeText(searchFrame, "⌕", UDim2.new(0, 10, 0, 0), UDim2.new(0, 20, 1, 0), {
            Font = Enum.Font.GothamBold,
            TextSize = 20,
            ColorKey = "Color Dark Text",
            Align = Enum.TextXAlignment.Center,
        })
        local searchBox = make("TextBox", {
            Name = "SearchBox",
            Position = UDim2.new(0, 34, 0, 0),
            Size = UDim2.new(1, -44, 1, 0),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Text = "",
            PlaceholderText = context.Localize("Search"),
            Font = Enum.Font.Gotham,
            TextSize = 11,
            TextColor3 = Theme:Get("Color Text"),
            PlaceholderColor3 = Theme:Get("Color Dark Text"),
            ClearTextOnFocus = false,
            TextXAlignment = Enum.TextXAlignment.Left,
        }, searchFrame)
        bind(searchBox, "TextColor3", "Color Text")
        bind(searchBox, "PlaceholderColor3", "Color Dark Text")

        local pages = make("Frame", {
            Name = "TabPages",
            Position = UDim2.new(0, 12, 0, 60),
            Size = UDim2.new(1, -24, 1, -72),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            ZIndex = 2,
        }, content)

        local footer = make("Frame", {
            Name = "Footer",
            Position = UDim2.new(0, 14, 1, -22),
            Size = UDim2.new(1, -28, 0, 16),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            ZIndex = 3,
        }, main)
        makeText(footer, "JustHub " .. tostring(Library.Info.Version), UDim2.new(0, 0, 0, 0), UDim2.new(0.6, 0, 1, 0), {
            TextSize = 9,
            ColorKey = "Color Dark Text",
        })
        makeText(footer, "READY", UDim2.new(1, -72, 0, 0), UDim2.new(0, 72, 1, 0), {
            TextSize = 9,
            ColorKey = "Color Theme",
            Font = Enum.Font.GothamBold,
            Align = Enum.TextXAlignment.Right,
        })

        local resizeHandle = make("TextButton", {
            Name = "ResizeHandle",
            Position = UDim2.new(1, -20, 1, -20),
            Size = UDim2.new(0, 18, 0, 18),
            BackgroundTransparency = 1,
            Text = "◢",
            Font = Enum.Font.GothamBold,
            TextSize = 12,
            TextColor3 = Theme:Get("Color Dark Text"),
            AutoButtonColor = false,
            ZIndex = 10,
        }, main)
        bind(resizeHandle, "TextColor3", "Color Dark Text")

        local notificationContainer = make("Frame", {
            Name = "NotificationContainer",
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.new(1, -18, 0, 18),
            Size = UDim2.new(0, 310, 1, -36),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            ZIndex = 100,
        }, screen)
        make("UIListLayout", {
            HorizontalAlignment = Enum.HorizontalAlignment.Right,
            VerticalAlignment = Enum.VerticalAlignment.Top,
            Padding = UDim.new(0, 8),
            SortOrder = Enum.SortOrder.LayoutOrder,
        }, notificationContainer)
        Library.NotificationContainer = notificationContainer

        local window = setmetatable({
            Name = tostring(options.Name or "JustHub"),
            ScreenGui = screen,
            MainFrame = main,
            Tabs = {},
            Scope = windowScope,
            Sidebar = sidebar,
            Content = content,
            SearchBox = searchBox,
            IsMaximized = false,
            IsMinimized = false,
            Locked = Library.Save.Locked == true,
            _restoreSize = UDim2.fromOffset(width, height),
            _restorePosition = UDim2.fromScale(0.5, 0.5),
        }, Window)
        Library.Window = window

        local function selectTab(activeTab)
            window.ActiveTab = activeTab
            for _, tab in ipairs(window.Tabs) do
                local active = tab == activeTab
                tab.Content.Visible = active
                tab.Indicator.Visible = active
                tab.Button.BackgroundColor3 = Theme:Get(active and "Color Hub 2" or "Color Hub 1")
                Theme:UpdateBinding(tab.Button, "BackgroundColor3", active and "Color Hub 2" or "Color Hub 1")
                tab.Label.TextColor3 = Theme:Get(active and "Color Text" or "Color Dark Text")
                Theme:UpdateBinding(tab.Label, "TextColor3", active and "Color Text" or "Color Dark Text")
                if tab.Icon then
                    tab.Icon.ImageColor3 = Theme:Get(active and "Color Text" or "Color Dark Text")
                    Theme:UpdateBinding(tab.Icon, "ImageColor3", active and "Color Text" or "Color Dark Text")
                end
            end
        end

        function window:SelectTab(tabName)
            for _, tab in ipairs(self.Tabs) do
                if tab.Name == tabName then
                    selectTab(tab)
                    return true
                end
            end
            return false
        end

        function window:addTab(tabName, iconName)
            tabName = tostring(tabName or "Tab")
            local tabScope = self.Scope:CreateScope("Tab:" .. tabName)
            local button = make("TextButton", {
                Name = tabName:gsub("[^%w_%-]", "") .. "TabButton",
                Size = UDim2.new(1, 0, 0, 38),
                BackgroundColor3 = Theme:Get("Color Hub 1"),
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                Text = "",
                AutoButtonColor = false,
                LayoutOrder = #self.Tabs + 1,
                ZIndex = 4,
            }, tabList)
            tabScope:TrackInstance(button)
            bind(button, "BackgroundColor3", "Color Hub 1")
            corner(button, 7)
            local indicator = make("Frame", {
                Name = "ActiveIndicator",
                Position = UDim2.new(0, 5, 0.5, -8),
                Size = UDim2.new(0, 3, 0, 16),
                BackgroundColor3 = Theme:Get("Color Theme"),
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                Visible = false,
                ZIndex = 5,
            }, button)
            bind(indicator, "BackgroundColor3", "Color Theme")
            corner(indicator, 2)
            local iconAsset = type(iconName) == "string" and Library.Icons[iconName] or nil
            local icon
            if iconAsset then
                icon = make("ImageLabel", {
                    Name = "TabIcon",
                    Position = UDim2.new(0, 14, 0.5, -8),
                    Size = UDim2.new(0, 16, 0, 16),
                    BackgroundTransparency = 1,
                    Image = iconAsset,
                    ImageColor3 = Theme:Get("Color Dark Text"),
                    ZIndex = 5,
                }, button)
                bind(icon, "ImageColor3", "Color Dark Text")
            end
            local textX = icon and 38 or 15
            local label = makeText(button, tabName, UDim2.new(0, textX, 0, 0), UDim2.new(1, -(textX + 8), 1, 0), {
                Font = Enum.Font.GothamMedium,
                TextSize = 11,
                ColorKey = "Color Dark Text",
                Truncate = true,
                ZIndex = 5,
            })
            local page = make("ScrollingFrame", {
                Name = tabName:gsub("[^%w_%-]", "") .. "Page",
                Size = UDim2.new(1, 0, 1, 0),
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                ScrollBarThickness = 3,
                AutomaticCanvasSize = Enum.AutomaticSize.Y,
                CanvasSize = UDim2.new(),
                Visible = false,
                ZIndex = 3,
            }, pages)
            tabScope:TrackInstance(page)
            bind(page, "ScrollBarImageColor3", "Color Stroke")
            make("UIListLayout", {
                Padding = UDim.new(0, 10),
                SortOrder = Enum.SortOrder.LayoutOrder,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
            }, page)
            make("UIPadding", {
                PaddingTop = UDim.new(0, 2),
                PaddingBottom = UDim.new(0, 10),
                PaddingLeft = UDim.new(0, 2),
                PaddingRight = UDim.new(0, 2),
            }, page)

            local tab = {
                Name = tabName,
                Button = button,
                Content = page,
                Sections = {},
                Indicator = indicator,
                Icon = icon,
                Label = label,
                Scope = tabScope,
            }
            table.insert(self.Tabs, tab)
            tabScope:Connect(button.Activated, function()
                selectTab(tab)
            end)
            tabScope:Connect(button.MouseEnter, function()
                if self.ActiveTab ~= tab then
                    tab.Button.BackgroundColor3 = Theme:Get("Color Stroke")
                end
            end)
            tabScope:Connect(button.MouseLeave, function()
                if self.ActiveTab ~= tab then
                    tab.Button.BackgroundColor3 = Theme:Get("Color Hub 1")
                end
            end)

            function tab:addSection(sectionName)
                sectionName = tostring(sectionName or "Section")
                local sectionScope = tabScope:CreateScope("Section:" .. sectionName)
                local frame = make("Frame", {
                    Name = sectionName:gsub("[^%w_%-]", "") .. "Section",
                    Size = UDim2.new(1, -4, 0, 0),
                    AutomaticSize = Enum.AutomaticSize.Y,
                    BackgroundColor3 = Theme:Get("Color Hub 2"),
                    BackgroundTransparency = 0,
                    BorderSizePixel = 0,
                    LayoutOrder = #tab.Sections + 1,
                    ZIndex = 3,
                }, page)
                sectionScope:TrackInstance(frame)
                bind(frame, "BackgroundColor3", "Color Hub 2")
                corner(frame, Theme.Tokens.Geometry.CardRadius)
                border(frame)
                makeText(frame, sectionName, UDim2.new(0, 12, 0, 0), UDim2.new(1, -24, 0, 36), {
                    Font = Enum.Font.GothamBold,
                    TextSize = 13,
                })
                local sectionContent = make("Frame", {
                    Name = "SectionContent",
                    Position = UDim2.new(0, 0, 0, 36),
                    Size = UDim2.new(1, 0, 0, 0),
                    AutomaticSize = Enum.AutomaticSize.Y,
                    BackgroundTransparency = 1,
                    BorderSizePixel = 0,
                }, frame)
                make("UIListLayout", {
                    Padding = UDim.new(0, 7),
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    HorizontalAlignment = Enum.HorizontalAlignment.Center,
                }, sectionContent)
                make("UIPadding", {
                    PaddingTop = UDim.new(0, 2),
                    PaddingBottom = UDim.new(0, 12),
                    PaddingLeft = UDim.new(0, 10),
                    PaddingRight = UDim.new(0, 10),
                }, sectionContent)

                local section = {
                    Name = sectionName,
                    Frame = frame,
                    Content = sectionContent,
                    TabName = tabName,
                    SectionName = sectionName,
                    Scope = sectionScope,
                    Controls = {},
                    _controlCounts = {},
                }
                function section:MakeControlId(controlName)
                    local base = Util.MakeId(self.TabName, self.SectionName, controlName)
                    local count = (self._controlCounts[base] or 0) + 1
                    self._controlCounts[base] = count
                    return count == 1 and base or (base .. "#" .. tostring(count))
                end
                setmetatable(section, {__index = Components})
                sectionScope:Connect(frame.Destroying, function()
                    sectionScope:Destroy()
                end)
                table.insert(tab.Sections, section)
                return section
            end
            tab.AddSection = tab.addSection

            if #self.Tabs == 1 then
                selectTab(tab)
            end
            return tab
        end
        window.AddTab = window.addTab

        local function applyResponsive()
            local newViewport = getViewport()
            local maxW = math.max(240, newViewport.X - 24)
            local maxH = math.max(200, newViewport.Y - 24)
            local minW = math.min(Theme.Tokens.Dimensions.MinWidth, maxW)
            local minH = math.min(Theme.Tokens.Dimensions.MinHeight, maxH)
            local desiredW = math.clamp(main.AbsoluteSize.X > 0 and main.AbsoluteSize.X or width, minW, maxW)
            local desiredH = math.clamp(main.AbsoluteSize.Y > 0 and main.AbsoluteSize.Y or height, minH, maxH)
            if not window.IsMaximized and not window.IsMinimized then
                main.Size = UDim2.fromOffset(desiredW, desiredH)
            end
            local compact = newViewport.X < 700 or desiredW < 520
            local targetSide = compact and 116 or sideWidth
            sidebar.Size = UDim2.new(0, targetSide, 1, -24)
            content.Position = UDim2.new(0, targetSide + 28, 0, 12)
            content.Size = UDim2.new(1, -(targetSide + 42), 1, -24)
            sidebarSubtitle.Visible = not compact
            playerCard.Visible = not compact
            tabList.Position = UDim2.new(0, 8, 0, compact and 64 or 118)
            tabList.Size = UDim2.new(1, -16, 1, compact and -76 or -130)
            if compact then
                sidebarTitle.Text = "JH"
                for _, tab in ipairs(window.Tabs) do
                    tab.Label.Visible = false
                    if tab.Icon then tab.Icon.Position = UDim2.new(0.5, -8, 0.5, -8) end
                end
            else
                sidebarTitle.Text = "JUSTHUB"
                for _, tab in ipairs(window.Tabs) do
                    tab.Label.Visible = true
                    if tab.Icon then tab.Icon.Position = UDim2.new(0, 14, 0.5, -8) end
                end
            end
        end

        local viewportConnection
        local function bindViewport(camera)
            if viewportConnection then
                windowScope:Disconnect(viewportConnection)
                viewportConnection = nil
            end
            if camera then
                viewportConnection = windowScope:Connect(camera:GetPropertyChangedSignal("ViewportSize"), applyResponsive)
            end
            applyResponsive()
        end
        windowScope:Connect(workspace:GetPropertyChangedSignal("CurrentCamera"), function()
            bindViewport(workspace.CurrentCamera)
        end)
        bindViewport(workspace.CurrentCamera)
        windowScope:Connect(searchBox:GetPropertyChangedSignal("Text"), function()
            local term = searchBox.Text:lower()
            for _, tab in ipairs(window.Tabs) do
                for _, section in ipairs(tab.Sections) do
                    local visibleCount = 0
                    for _, child in ipairs(section.Controls) do
                        local searchable = child:GetAttribute("JustHubSearch") or child.Name
                        local visible = term == "" or tostring(searchable):lower():find(term, 1, true) ~= nil
                        child.Visible = visible
                        if visible then visibleCount += 1 end
                    end
                    section.Frame.Visible = term == "" or visibleCount > 0
                end
            end
        end)

        windowScope:Connect(minimizeButton.Activated, function()
            if window.IsMinimized then
                window.IsMinimized = false
                body.Visible = true
                footer.Visible = true
                main.Size = window._restoreSize
            else
                window._restoreSize = main.Size
                window.IsMinimized = true
                body.Visible = false
                footer.Visible = false
                main.Size = UDim2.new(0, main.AbsoluteSize.X, 0, Theme.Tokens.Dimensions.Header)
            end
        end)
        windowScope:Connect(maximizeButton.Activated, function()
            if window.IsMaximized then
                window.IsMaximized = false
                main.Size = window._restoreSize
                main.Position = window._restorePosition
            else
                window._restoreSize = main.Size
                window._restorePosition = main.Position
                window.IsMaximized = true
                local current = getViewport()
                main.Size = UDim2.fromOffset(math.max(240, current.X - 24), math.max(200, current.Y - 24))
                main.Position = UDim2.fromScale(0.5, 0.5)
            end
            applyResponsive()
        end)
        windowScope:Connect(lockButton.Activated, function()
            window.Locked = not window.Locked
            Library.Save.Locked = window.Locked
            lockButton.Text = window.Locked and "L" or "U"
            lockButton.BackgroundColor3 = Theme:Get(window.Locked and "Color Theme" or "Color Hub 2")
            Theme:UpdateBinding(lockButton, "BackgroundColor3", window.Locked and "Color Theme" or "Color Hub 2")
            Library:Notify({Title = "Window", Message = window.Locked and "Window movement locked" or "Window movement unlocked", Duration = 2})
        end)
        windowScope:Connect(closeButton.Activated, function()
            Library:Destroy()
        end)

        local dragInput, dragStart, startPosition
        windowScope:Connect(header.InputBegan, function(input)
            if window.Locked or window.IsMaximized then return end
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                dragInput = input
                dragStart = input.Position
                startPosition = main.Position
            end
        end)
        windowScope:Connect(UserInputService.InputChanged, function(input)
            if not dragInput then return end
            local matchingMouse = dragInput.UserInputType == Enum.UserInputType.MouseButton1
                and input.UserInputType == Enum.UserInputType.MouseMovement
            local matchingTouch = dragInput.UserInputType == Enum.UserInputType.Touch and input == dragInput
            if matchingMouse or matchingTouch then
                local delta = input.Position - dragStart
                main.Position = UDim2.new(
                    startPosition.X.Scale, startPosition.X.Offset + delta.X,
                    startPosition.Y.Scale, startPosition.Y.Offset + delta.Y
                )
            end
        end)
        windowScope:Connect(UserInputService.InputEnded, function(input)
            if dragInput and (input == dragInput or (dragInput.UserInputType == Enum.UserInputType.MouseButton1 and input.UserInputType == Enum.UserInputType.MouseButton1)) then
                dragInput = nil
            end
        end)

        local resizeInput, resizeStart, resizeSize
        windowScope:Connect(resizeHandle.InputBegan, function(input)
            if window.Locked or window.IsMaximized or window.IsMinimized then return end
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                resizeInput = input
                resizeStart = input.Position
                resizeSize = main.AbsoluteSize
            end
        end)
        windowScope:Connect(UserInputService.InputChanged, function(input)
            if not resizeInput then return end
            local matchingMouse = resizeInput.UserInputType == Enum.UserInputType.MouseButton1
                and input.UserInputType == Enum.UserInputType.MouseMovement
            local matchingTouch = resizeInput.UserInputType == Enum.UserInputType.Touch and input == resizeInput
            if matchingMouse or matchingTouch then
                local delta = input.Position - resizeStart
                local current = getViewport()
                local maxWidth = math.max(240, current.X - 24)
                local maxHeight = math.max(200, current.Y - 24)
                local newWidth = math.clamp(resizeSize.X + delta.X, math.min(Theme.Tokens.Dimensions.MinWidth, maxWidth), maxWidth)
                local newHeight = math.clamp(resizeSize.Y + delta.Y, math.min(Theme.Tokens.Dimensions.MinHeight, maxHeight), maxHeight)
                main.Size = UDim2.fromOffset(newWidth, newHeight)
                window._restoreSize = main.Size
                Library.Save.UISize = {newWidth, newHeight}
                applyResponsive()
            end
        end)
        windowScope:Connect(UserInputService.InputEnded, function(input)
            if resizeInput and (input == resizeInput or (resizeInput.UserInputType == Enum.UserInputType.MouseButton1 and input.UserInputType == Enum.UserInputType.MouseButton1)) then
                resizeInput = nil
            end
        end)

        function window:Show()
            if self.ScreenGui and self.ScreenGui.Parent then self.ScreenGui.Enabled = true end
        end
        function window:Hide()
            if self.ScreenGui and self.ScreenGui.Parent then self.ScreenGui.Enabled = false end
        end
        function window:Toggle()
            if self.ScreenGui and self.ScreenGui.Parent then self.ScreenGui.Enabled = not self.ScreenGui.Enabled end
        end
        function window:SetTitle(newTitle)
            title.Text = tostring(newTitle or "JustHub")
        end
        function window:SetSubtitle(newSubtitle)
            subtitle.Text = tostring(newSubtitle or "")
        end
        function window:SetSize(newWidth, newHeight)
            local current = getViewport()
            local maxWidth = math.max(240, current.X - 24)
            local maxHeight = math.max(200, current.Y - 24)
            local widthValue = math.clamp(tonumber(newWidth) or width, math.min(Theme.Tokens.Dimensions.MinWidth, maxWidth), maxWidth)
            local heightValue = math.clamp(tonumber(newHeight) or height, math.min(Theme.Tokens.Dimensions.MinHeight, maxHeight), maxHeight)
            main.Size = UDim2.fromOffset(widthValue, heightValue)
            self._restoreSize = main.Size
            Library.Save.UISize = {widthValue, heightValue}
            applyResponsive()
        end
        function window:Destroy()
            Library:Destroy()
        end
        window.AddTab = window.addTab
        applyResponsive()
        if window.Locked then
            lockButton.Text = "L"
            lockButton.BackgroundColor3 = Theme:Get("Color Theme")
            Theme:UpdateBinding(lockButton, "BackgroundColor3", "Color Theme")
        end
        return window
        end, debug.traceback)
        if not buildOk then
            if createdScope then createdScope:Destroy() end
            error(builtWindow, 0)
        end
        return builtWindow
    end

    return Window
end
