return {
    Util = require(script.Parent.Core.Util),
    ResourceManager = require(script.Parent.Core.ResourceManager),
    ThemeManager = require(script.Parent.Core.ThemeManager),
    StateManager = require(script.Parent.Core.StateManager),
    StorageAdapter = require(script.Parent.Core.StorageAdapter),
    ConfigManager = require(script.Parent.Core.ConfigManager),
    Localization = require(script.Parent.Services.Localization),
    Permissions = require(script.Parent.Services.Permissions),
    Sound = require(script.Parent.Services.Sound),
    Components = require(script.Parent.UI.Components),
    Window = require(script.Parent.UI.Window),
    Notifications = require(script.Parent.UI.Notifications),
}
