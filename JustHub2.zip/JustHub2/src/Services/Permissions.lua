local Permissions = {}
Permissions.__index = Permissions

local DEFAULT_ROLES = {
    guest = 0,
    member = 10,
    moderator = 50,
    admin = 100,
}

function Permissions.new()
    return setmetatable({
        Roles = table.clone(DEFAULT_ROLES),
        CurrentRole = "member",
    }, Permissions)
end

function Permissions:RegisterRole(name, rank)
    if type(name) ~= "string" or name == "" or type(rank) ~= "number"
        or rank ~= rank or rank == math.huge or rank == -math.huge then
        return false, "Role requires a name and numeric rank"
    end
    self.Roles[name] = rank
    return true
end

function Permissions:SetRole(name)
    if type(name) ~= "string" or self.Roles[name] == nil then
        return false, "Unknown role"
    end
    self.CurrentRole = name
    return true
end

function Permissions:Check(requiredRole)
    if type(requiredRole) ~= "string" or self.Roles[requiredRole] == nil then
        return false
    end
    return self.Roles[self.CurrentRole] >= self.Roles[requiredRole]
end

function Permissions:Destroy()
    table.clear(self.Roles)
end

return Permissions
