local Localization = {}
Localization.__index = Localization

local BUILTIN = {
    en = {
        Search = "Search controls...",
        Select = "Select...",
        SearchOptions = "Search options...",
        SelectAll = "Select all",
        ClearAll = "Clear all",
        InputHere = "Type here...",
        PasteHere = "Paste text here...",
        Run = "Run",
        SaveProfile = "Save profile",
        LoadProfile = "Load profile",
        DeleteProfile = "Delete profile",
        ConfigName = "Profile name...",
        PressKey = "Press a key...",
        Locked = "Locked",
        Unlocked = "Unlocked",
    },
    id = {
        Search = "Cari kontrol...",
        Select = "Pilih...",
        SearchOptions = "Cari opsi...",
        SelectAll = "Pilih semua",
        ClearAll = "Hapus semua",
        InputHere = "Ketik di sini...",
        PasteHere = "Tempel teks di sini...",
        Run = "Jalankan",
        SaveProfile = "Simpan profil",
        LoadProfile = "Muat profil",
        DeleteProfile = "Hapus profil",
        ConfigName = "Nama profil...",
        PressKey = "Tekan tombol...",
        Locked = "Terkunci",
        Unlocked = "Tidak terkunci",
    },
}

function Localization.new()
    return setmetatable({
        Current = "en",
        Languages = table.clone(BUILTIN),
    }, Localization)
end

function Localization:RegisterLanguage(language, dictionary)
    if type(language) ~= "string" or language == "" or type(dictionary) ~= "table" then
        return false, "Language and dictionary are required"
    end
    self.Languages[language] = table.clone(dictionary)
    return true
end

function Localization:SetLanguage(language)
    if type(language) ~= "string" or language == "" then
        return false, "Language code must be a non-empty string"
    end
    if not self.Languages[language] then
        return false, "Language is not registered: " .. language
    end
    self.Current = language
    return true
end

function Localization:Get(key)
    local text = self.Languages[self.Current] and self.Languages[self.Current][key]
    if text == nil then
        text = self.Languages.en[key]
    end
    return text or tostring(key)
end

return Localization
