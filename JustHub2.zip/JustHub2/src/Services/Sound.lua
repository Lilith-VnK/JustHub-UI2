return function(context)
    local Instance = context.Instance
    local SoundService = context.SoundService
    local RootScope = context.RootScope

    local Sound = {}
    Sound.__index = Sound

    function Sound.new()
        return setmetatable({
            Sounds = {
                ButtonClick = 0,
                SliderMove = 0,
            },
        }, Sound)
    end

    function Sound:Play(name, volume)
        local assetId = self.Sounds[name]
        local numericId = tonumber(assetId)
        if not numericId or numericId <= 0 then
            return false, "Sound is not configured"
        end

        local scope = RootScope:CreateScope("Sound:" .. tostring(name))
        local audio = Instance.new("Sound")
        audio.Name = "JustHubSound"
        audio.SoundId = "rbxassetid://" .. tostring(math.floor(numericId))
        audio.Volume = math.clamp(tonumber(volume) or 0.6, 0, 1)
        audio.Parent = SoundService
        scope:TrackInstance(audio)
        scope:Connect(audio.Ended, function()
            scope:Destroy()
        end)
        local ok, err = pcall(function()
            audio:Play()
        end)
        if not ok then
            scope:Destroy()
            return false, tostring(err)
        end
        scope:Delay(15, function()
            scope:Destroy()
        end)
        return true
    end

    return Sound
end
