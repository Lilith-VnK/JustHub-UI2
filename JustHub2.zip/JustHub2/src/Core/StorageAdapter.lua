local StorageAdapter = {}
StorageAdapter.__index = StorageAdapter

local function getExecutorEnvironment()
    local environment = _G
    if type(getgenv) == "function" then
        local ok, result = pcall(getgenv)
        if ok and type(result) == "table" then
            environment = result
        end
    elseif type(getfenv) == "function" then
        local ok, result = pcall(getfenv, 0)
        if ok and type(result) == "table" then
            environment = result
        end
    end
    return environment
end

function StorageAdapter.new(options)
    options = options or {}
    local environment = getExecutorEnvironment()
    local function resolve(name)
        return rawget(environment, name) or rawget(_G, name)
    end
    return setmetatable({
        Environment = environment,
        ReadFile = resolve("readfile"),
        WriteFile = resolve("writefile"),
        DeleteFile = resolve("delfile"),
        IsFile = resolve("isfile"),
        MakeFolder = resolve("makefolder"),
        IsFolder = resolve("isfolder"),
        Folder = type(options.Folder) == "string" and options.Folder or "",
    }, StorageAdapter)
end

function StorageAdapter:Capabilities()
    return {
        Read = type(self.ReadFile) == "function",
        Write = type(self.WriteFile) == "function",
        Delete = type(self.DeleteFile) == "function",
        IsFile = type(self.IsFile) == "function",
        MakeFolder = type(self.MakeFolder) == "function",
        IsFolder = type(self.IsFolder) == "function",
    }
end

function StorageAdapter:NormalizeName(fileName)
    local name = tostring(fileName or "")
    name = name:gsub("\\", "/")
    if name == "" then
        return nil, "Filename is empty"
    end
    if name:lower():sub(-5) ~= ".json" then
        name ..= ".json"
    end
    if #name > 128 or name == ".json" or name:find("%z")
        or name == "." or name == ".." or name:find("..", 1, true)
        or name:find("/", 1, true) or name:find(":", 1, true) then
        return nil, "Filename contains an invalid path or character"
    end
    if name == "." or name == ".." then
        return nil, "Filename is invalid"
    end
    return self.Folder ~= "" and (self.Folder .. "/" .. name) or name
end

function StorageAdapter:_EnsureFolder()
    if self.Folder == "" then
        return true
    end
    if type(self.MakeFolder) ~= "function" then
        return false, "makefolder is not supported by this executor"
    end
    local exists = false
    local isFolder = self.IsFolder
    if type(isFolder) == "function" then
        local ok, result = pcall(isFolder, self.Folder)
        exists = ok and result == true
    end
    if not exists then
        local ok, err = pcall(self.MakeFolder, self.Folder)
        if not ok then
            return false, tostring(err)
        end
    end
    return true
end

function StorageAdapter:Write(fileName, content)
    if type(self.WriteFile) ~= "function" then
        return false, "writefile is not supported by this executor"
    end
    local path, pathError = self:NormalizeName(fileName)
    if not path then
        return false, pathError
    end
    local folderOk, folderError = self:_EnsureFolder()
    if not folderOk then
        return false, folderError
    end
    local ok, err = pcall(self.WriteFile, path, content)
    if not ok then
        return false, tostring(err)
    end
    return true, path
end

function StorageAdapter:Read(fileName)
    if type(self.ReadFile) ~= "function" then
        return false, "readfile is not supported by this executor"
    end
    local path, pathError = self:NormalizeName(fileName)
    if not path then
        return false, pathError
    end
    if type(self.IsFile) == "function" then
        local existsOk, exists = pcall(self.IsFile, path)
        if existsOk and not exists then
            return false, "Configuration file does not exist: " .. path
        end
    end
    local ok, content = pcall(self.ReadFile, path)
    if not ok then
        return false, tostring(content)
    end
    if type(content) ~= "string" or content == "" then
        return false, "Configuration file is empty or unreadable"
    end
    return true, content, path
end

function StorageAdapter:Delete(fileName)
    if type(self.DeleteFile) ~= "function" then
        return false, "delfile is not supported by this executor"
    end
    local path, pathError = self:NormalizeName(fileName)
    if not path then
        return false, pathError
    end
    local ok, err = pcall(self.DeleteFile, path)
    if not ok then
        return false, tostring(err)
    end
    return true, path
end

return StorageAdapter
