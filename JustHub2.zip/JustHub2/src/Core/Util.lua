local Util = {}

function Util.IsFinite(value)
    return type(value) == "number"
        and value == value
        and value ~= math.huge
        and value ~= -math.huge
end

function Util.ClampNumber(value, minimum, maximum, fallback)
    local number = tonumber(value)
    if not Util.IsFinite(number) then
        number = fallback or minimum or 0
    end
    return math.clamp(number, minimum, maximum)
end

function Util.ShallowClone(source)
    local copy = {}
    if type(source) == "table" then
        for key, value in pairs(source) do
            copy[key] = value
        end
    end
    return copy
end

function Util.Clone(value, seen)
    if type(value) ~= "table" then
        return value
    end

    seen = seen or {}
    if seen[value] then
        return seen[value]
    end

    local copy = {}
    seen[value] = copy
    for key, child in pairs(value) do
        copy[Util.Clone(key, seen)] = Util.Clone(child, seen)
    end
    return copy
end

function Util.DeepEqual(left, right, seen)
    if left == right then
        return true
    end
    if type(left) ~= "table" or type(right) ~= "table" then
        return false
    end

    seen = seen or {}
    if seen[left] == right then
        return true
    end
    seen[left] = right

    for key, value in pairs(left) do
        if not Util.DeepEqual(value, right[key], seen) then
            return false
        end
    end
    for key in pairs(right) do
        if left[key] == nil then
            return false
        end
    end
    return true
end

function Util.NormalizeStringArray(value)
    local result, seen = {}, {}
    if type(value) ~= "table" then
        return result
    end
    for _, item in ipairs(value) do
        if type(item) == "string" and item ~= "" and not seen[item] then
            seen[item] = true
            table.insert(result, item)
        end
    end
    return result
end

function Util.SafeCall(label, callback, ...)
    if type(callback) ~= "function" then
        return false, "Callback is not a function"
    end
    local args = table.pack(...)
    local ok, result = xpcall(function()
        return callback(table.unpack(args, 1, args.n))
    end, debug.traceback)
    if not ok then
        warn("[JustHub] " .. tostring(label or "Operation") .. ": " .. tostring(result))
    end
    return ok, result
end

function Util.MakeId(...)
    local parts = table.pack(...)
    local output = table.create(parts.n)
    for index = 1, parts.n do
        local value = tostring(parts[index] or "")
        value = value:gsub("[%c/\\]+", "_"):gsub("%s+", " ")
        output[index] = value
    end
    return table.concat(output, "/")
end

function Util.SafeDestroy(instance)
    if instance then
        pcall(function()
            instance:Destroy()
        end)
    end
end

function Util.IsDenseArray(value)
    if type(value) ~= "table" then
        return false
    end
    local count, maximum = 0, 0
    for key, item in pairs(value) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false
        end
        if item == nil then
            return false
        end
        count += 1
        maximum = math.max(maximum, key)
    end
    return count == maximum
end

function Util.Trim(value)
    return tostring(value or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

return Util
