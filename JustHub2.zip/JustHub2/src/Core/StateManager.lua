local StateManager = {}
StateManager.__index = StateManager

local function cloneValue(value)
    if type(value) == "table" then
        local seen = {}
        local function clone(source)
            if type(source) ~= "table" then
                return source
            end
            if seen[source] then
                return seen[source]
            end
            local copy = {}
            seen[source] = copy
            for key, item in pairs(source) do
                copy[clone(key)] = clone(item)
            end
            return copy
        end
        return clone(value)
    end
    return value
end

function StateManager.new(options)
    options = options or {}
    return setmetatable({
        Values = {},
        Registry = {},
        Aliases = {},
        AmbiguousAliases = {},
        Controls = {},
        UndoStack = {},
        RedoStack = {},
        HistoryLimit = options.HistoryLimit or 100,
        Applying = false,
        Destroyed = false,
    }, StateManager)
end

function StateManager:_Warn(message)
    warn("[JustHub] " .. tostring(message))
end

function StateManager:_Resolve(id)
    if type(id) ~= "string" or id == "" then
        return nil, nil, "Control ID must be a non-empty string"
    end
    if self.Registry[id] then
        return id, self.Registry[id]
    end
    if self.AmbiguousAliases[id] then
        return nil, nil, "Ambiguous control alias; use the full control ID"
    end
    local canonical = self.Aliases[id]
    if canonical then
        return canonical, self.Registry[canonical]
    end
    return nil, nil, "Unknown control: " .. tostring(id)
end

function StateManager:_RegisterAlias(id, alias)
    if type(alias) ~= "string" or alias == "" or alias == id then
        return
    end
    if self.AmbiguousAliases[alias] then
        return
    end
    local existing = self.Aliases[alias]
    if existing and existing ~= id then
        self.Aliases[alias] = nil
        self.AmbiguousAliases[alias] = true
        self.Controls[alias] = nil
        self:_Warn("Ambiguous short control name '" .. alias .. "'; use the full ID")
        return
    end
    if not self.Registry[alias] then
        self.Aliases[alias] = id
        self.Controls[alias] = self.Controls[id]
    end
end

function StateManager:Create(id, defaultValue, validator, renderer, callback, metadata)
    if self.Destroyed then
        return nil, "State manager is destroyed"
    end
    if type(id) ~= "string" or id == "" then
        return nil, "Control ID must be a non-empty string"
    end
    if self.Registry[id] then
        return nil, "Control ID already registered: " .. id
    end

    local record = {
        Id = id,
        Value = cloneValue(defaultValue),
        Validator = validator,
        Renderer = renderer,
        Callback = callback,
        Metadata = metadata or {},
        EditStart = nil,
        Destroyed = false,
    }
    local handle = {Id = id}
    local selfManager = self
    record.Handle = handle
    self.Registry[id] = record
    self.Values[id] = cloneValue(defaultValue)
    self.Controls[id] = record.Metadata
    self:_RegisterAlias(id, record.Metadata.shortName or record.Metadata.ShortName)

    function handle:Get()
        return cloneValue(record.Value)
    end
    function handle:Set(value, applyOptions)
        return selfManager:Set(id, value, applyOptions)
    end
    function handle:SetLive(value, applyOptions)
        local options = table.clone(applyOptions or {})
        options.skipHistory = true
        return selfManager:Set(id, value, options)
    end
    function handle:BeginEdit()
        record.EditStart = cloneValue(record.Value)
    end
    function handle:EndEdit(dispatchCallback)
        local changed = record.EditStart ~= nil and not selfManager:_Equal(record.EditStart, record.Value)
        if changed and not selfManager.Applying then
            selfManager:AddUndo(id, record.EditStart, record.Value)
        end
        record.EditStart = nil
        if changed and dispatchCallback == true and type(record.Callback) == "function" then
            local callback = record.Callback
            local callbackValue = cloneValue(record.Value)
            task.defer(function()
                if not selfManager.Destroyed and not record.Destroyed then
                    local ok, err = xpcall(function() callback(callbackValue) end, debug.traceback)
                    if not ok then selfManager:_Warn("Callback failed for '" .. id .. "': " .. tostring(err)) end
                end
            end)
        end
    end
    function handle:Destroy()
        selfManager:Unregister(id)
    end

    if type(renderer) == "function" then
        local ok, err = pcall(renderer, cloneValue(defaultValue))
        if not ok then
            self:Unregister(id)
            return nil, "Initial render failed: " .. tostring(err)
        end
    end
    return handle
end

function StateManager:_Equal(left, right)
    if left == right then
        return true
    end
    if type(left) ~= "table" or type(right) ~= "table" then
        return false
    end
    local function equal(a, b, visited)
        if a == b then return true end
        if type(a) ~= "table" or type(b) ~= "table" then return false end
        visited = visited or {}
        if visited[a] == b then return true end
        visited[a] = b
        for key, value in pairs(a) do
            if not equal(value, b[key], visited) then return false end
        end
        for key in pairs(b) do
            if a[key] == nil then return false end
        end
        return true
    end
    return equal(left, right)
end

function StateManager:Set(id, value, applyOptions)
    if self.Destroyed then
        return false, "State manager is destroyed"
    end
    local canonical, record, resolveError = self:_Resolve(id)
    if not record then
        return false, resolveError
    end
    if record.Destroyed then
        return false, "Control is destroyed"
    end

    applyOptions = type(applyOptions) == "table" and applyOptions or {}
    if type(record.ExternalSetter) == "function" then
        local ok, result, reason = pcall(record.ExternalSetter, cloneValue(value))
        if not ok then return false, result end
        if result == false then return false, reason or "External control rejected the value" end
        return true, true
    end
    if type(record.Validator) == "function" then
        local validatorOk, valid, reason = pcall(record.Validator, value)
        if not validatorOk then
            return false, "Validator failed: " .. tostring(valid)
        end
        if valid ~= true then
            return false, reason or "Invalid control value"
        end
    end

    local oldValue = cloneValue(record.Value)
    local newValue = cloneValue(value)
    if self:_Equal(oldValue, newValue) then
        return true, false
    end

    record.Value = cloneValue(newValue)
    self.Values[canonical] = cloneValue(newValue)
    if type(record.Renderer) == "function" and not applyOptions.skipRender then
        local ok, err = pcall(record.Renderer, cloneValue(newValue))
        if not ok then
            record.Value = cloneValue(oldValue)
            self.Values[canonical] = cloneValue(oldValue)
            pcall(record.Renderer, cloneValue(oldValue))
            self:_Warn("Render failed for '" .. canonical .. "': " .. tostring(err))
            return false, err
        end
    end

    if not applyOptions.skipHistory and not self.Applying then
        self:AddUndo(canonical, oldValue, newValue)
    end
    if not applyOptions.skipCallback and type(record.Callback) == "function" then
        local callback = record.Callback
        local callbackValue = cloneValue(newValue)
        task.defer(function()
            if not self.Destroyed and not record.Destroyed then
                local ok, err = xpcall(function()
                    callback(callbackValue)
                end, debug.traceback)
                if not ok then
                    self:_Warn("Callback failed for '" .. canonical .. "': " .. tostring(err))
                end
            end
        end)
    end
    return true, true
end

function StateManager:RegisterExternal(id, setter, metadata)
    metadata = type(metadata) == "table" and metadata or {}
    if type(id) ~= "string" or id == "" or type(setter) ~= "function" then
        return false, "Invalid external control registration"
    end
    if self.Registry[id] then
        return false, "Control ID already registered: " .. id
    end
    local record = {
        Id = id,
        ExternalSetter = setter,
        Metadata = metadata,
        Destroyed = false,
    }
    self.Registry[id] = record
    self.Controls[id] = metadata
    self:_RegisterAlias(id, metadata.shortName or metadata.ShortName)
    return true
end

function StateManager:Unregister(id)
    local canonical = self.Registry[id] and id or self.Aliases[id]
    if not canonical then
        return false
    end
    local record = self.Registry[canonical]
    if record then
        record.Destroyed = true
        self.Registry[canonical] = nil
        self.Values[canonical] = nil
        self.Controls[canonical] = nil
    end
    for alias, target in pairs(self.Aliases) do
        if target == canonical then
            self.Aliases[alias] = nil
            self.Controls[alias] = nil
        end
    end
    for index = #self.UndoStack, 1, -1 do
        if self.UndoStack[index].Id == canonical then
            table.remove(self.UndoStack, index)
        end
    end
    for index = #self.RedoStack, 1, -1 do
        if self.RedoStack[index].Id == canonical then
            table.remove(self.RedoStack, index)
        end
    end
    return true
end

function StateManager:AddUndo(id, oldValue, newValue)
    if type(id) ~= "string" then return false end
    local canonical = self.Registry[id] and id or self.Aliases[id]
    if not canonical then return false end
    id = canonical
    if self.Applying or self.Destroyed or self:_Equal(oldValue, newValue) then
        return false
    end
    local last = self.UndoStack[#self.UndoStack]
    if last and last.Id == id and self:_Equal(last.New, oldValue) then
        last.New = cloneValue(newValue)
    else
        table.insert(self.UndoStack, {
            Id = id,
            Old = cloneValue(oldValue),
            New = cloneValue(newValue),
        })
        if #self.UndoStack > self.HistoryLimit then
            table.remove(self.UndoStack, 1)
        end
    end
    table.clear(self.RedoStack)
    return true
end

function StateManager:_ApplyHistory(id, value)
    local record = self.Registry[id]
    if not record then
        return false, "Control is no longer registered"
    end
    if record.ExternalSetter then
        local ok, result, reason = pcall(record.ExternalSetter, cloneValue(value))
        if not ok then return false, result end
        if result == false then return false, reason or "External control rejected the value" end
        return true
    end
    self.Applying = true
    local ok, err = self:Set(id, value, {skipHistory = true})
    self.Applying = false
    return ok, err
end

function StateManager:Undo()
    local entry = self.UndoStack[#self.UndoStack]
    if not entry then
        return false, "Nothing to undo"
    end
    local ok, err = self:_ApplyHistory(entry.Id, entry.Old)
    if not ok then
        return false, err
    end
    table.remove(self.UndoStack)
    table.insert(self.RedoStack, entry)
    return true
end

function StateManager:Redo()
    local entry = self.RedoStack[#self.RedoStack]
    if not entry then
        return false, "Nothing to redo"
    end
    local ok, err = self:_ApplyHistory(entry.Id, entry.New)
    if not ok then
        return false, err
    end
    table.remove(self.RedoStack)
    table.insert(self.UndoStack, entry)
    return true
end

function StateManager:ApplyConfig(values)
    if type(values) ~= "table" then
        return false, "Configuration values must be a table"
    end
    local previous = self.Applying
    self.Applying = true
    local applied, skipped = 0, 0
    local canonicalSet = {}

    local function applyRecord(record, value)
        if not record then return false end
        if record.ExternalSetter then
            local ok, result = pcall(record.ExternalSetter, cloneValue(value))
            return ok and result ~= false
        end
        local ok = self:Set(record.Id, value, {skipHistory = true})
        return ok == true
    end

    local loopOk, loopError = xpcall(function()
        for key, value in pairs(values) do
            local record = self.Registry[key]
            if record then
                canonicalSet[key] = true
                if applyRecord(record, value) then applied += 1 else skipped += 1 end
            end
        end

        for key, value in pairs(values) do
            if not self.Registry[key] then
                local canonical = self.Aliases[key]
                local record = canonical and self.Registry[canonical]
                if record and not canonicalSet[canonical] then
                    if applyRecord(record, value) then applied += 1 else skipped += 1 end
                else
                    skipped += 1
                end
            end
        end
    end, debug.traceback)

    self.Applying = previous
    if not loopOk then
        self:_Warn("Configuration application aborted: " .. tostring(loopError))
        return false, loopError
    end
    table.clear(self.UndoStack)
    table.clear(self.RedoStack)
    return true, {Applied = applied, Skipped = skipped}
end

function StateManager:Destroy()
    if self.Destroyed then
        return
    end
    self.Destroyed = true
    for _, record in pairs(self.Registry) do
        record.Destroyed = true
    end
    table.clear(self.Registry)
    table.clear(self.Values)
    table.clear(self.Aliases)
    table.clear(self.AmbiguousAliases)
    table.clear(self.Controls)
    table.clear(self.UndoStack)
    table.clear(self.RedoStack)
end

return StateManager
