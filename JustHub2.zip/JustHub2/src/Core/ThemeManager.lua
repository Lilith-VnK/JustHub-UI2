local ThemeManager = {}
ThemeManager.__index = ThemeManager

local REQUIRED_KEYS = {
    "Color Hub 1", "Color Hub 2", "Color Stroke",
    "Color Theme", "Color Text", "Color Dark Text",
}

local THEMES = {
    Darker = { ["Color Hub 1"] = Color3.fromRGB(18, 24, 34), ["Color Hub 2"] = Color3.fromRGB(25, 33, 46), ["Color Stroke"] = Color3.fromRGB(54, 68, 86), ["Color Theme"] = Color3.fromRGB(82, 211, 165), ["Color Text"] = Color3.fromRGB(239, 245, 250), ["Color Dark Text"] = Color3.fromRGB(171, 185, 201) },
    Dark = { ["Color Hub 1"] = Color3.fromRGB(25, 25, 30), ["Color Hub 2"] = Color3.fromRGB(35, 35, 40), ["Color Stroke"] = Color3.fromRGB(60, 60, 70), ["Color Theme"] = Color3.fromRGB(80, 200, 255), ["Color Text"] = Color3.fromRGB(245, 245, 250), ["Color Dark Text"] = Color3.fromRGB(170, 170, 180) },
    Purple = { ["Color Hub 1"] = Color3.fromRGB(20, 15, 30), ["Color Hub 2"] = Color3.fromRGB(30, 25, 40), ["Color Stroke"] = Color3.fromRGB(50, 40, 65), ["Color Theme"] = Color3.fromRGB(150, 100, 255), ["Color Text"] = Color3.fromRGB(240, 240, 245), ["Color Dark Text"] = Color3.fromRGB(170, 160, 190) },
    Light = { ["Color Hub 1"] = Color3.fromRGB(210, 210, 215), ["Color Hub 2"] = Color3.fromRGB(230, 230, 235), ["Color Stroke"] = Color3.fromRGB(180, 180, 190), ["Color Theme"] = Color3.fromRGB(0, 140, 255), ["Color Text"] = Color3.fromRGB(40, 40, 45), ["Color Dark Text"] = Color3.fromRGB(90, 90, 100) },
    Neon = { ["Color Hub 1"] = Color3.fromRGB(5, 5, 10), ["Color Hub 2"] = Color3.fromRGB(10, 10, 15), ["Color Stroke"] = Color3.fromRGB(0, 255, 255), ["Color Theme"] = Color3.fromRGB(0, 255, 100), ["Color Text"] = Color3.fromRGB(255, 255, 255), ["Color Dark Text"] = Color3.fromRGB(200, 255, 255) },
    Forest = { ["Color Hub 1"] = Color3.fromRGB(0, 30, 15), ["Color Hub 2"] = Color3.fromRGB(0, 45, 25), ["Color Stroke"] = Color3.fromRGB(0, 75, 35), ["Color Theme"] = Color3.fromRGB(50, 205, 50), ["Color Text"] = Color3.fromRGB(230, 255, 230), ["Color Dark Text"] = Color3.fromRGB(170, 200, 170) },
    Aqua = { ["Color Hub 1"] = Color3.fromRGB(0, 70, 80), ["Color Hub 2"] = Color3.fromRGB(0, 100, 110), ["Color Stroke"] = Color3.fromRGB(0, 160, 180), ["Color Theme"] = Color3.fromRGB(0, 230, 255), ["Color Text"] = Color3.fromRGB(250, 255, 255), ["Color Dark Text"] = Color3.fromRGB(200, 230, 240) },
    Crimson = { ["Color Hub 1"] = Color3.fromRGB(35, 0, 5), ["Color Hub 2"] = Color3.fromRGB(60, 0, 10), ["Color Stroke"] = Color3.fromRGB(110, 0, 20), ["Color Theme"] = Color3.fromRGB(255, 50, 80), ["Color Text"] = Color3.fromRGB(255, 240, 240), ["Color Dark Text"] = Color3.fromRGB(220, 180, 180) },
    Solar = { ["Color Hub 1"] = Color3.fromRGB(230, 190, 0), ["Color Hub 2"] = Color3.fromRGB(255, 210, 0), ["Color Stroke"] = Color3.fromRGB(255, 150, 0), ["Color Theme"] = Color3.fromRGB(255, 80, 0), ["Color Text"] = Color3.fromRGB(30, 30, 30), ["Color Dark Text"] = Color3.fromRGB(70, 70, 70) },
    Pastel = { ["Color Hub 1"] = Color3.fromRGB(210, 190, 220), ["Color Hub 2"] = Color3.fromRGB(235, 220, 245), ["Color Stroke"] = Color3.fromRGB(180, 160, 200), ["Color Theme"] = Color3.fromRGB(170, 210, 240), ["Color Text"] = Color3.fromRGB(70, 70, 70), ["Color Dark Text"] = Color3.fromRGB(110, 110, 110) },
    Cyber = { ["Color Hub 1"] = Color3.fromRGB(5, 5, 20), ["Color Hub 2"] = Color3.fromRGB(15, 15, 35), ["Color Stroke"] = Color3.fromRGB(0, 220, 255), ["Color Theme"] = Color3.fromRGB(0, 180, 255), ["Color Text"] = Color3.fromRGB(250, 255, 255), ["Color Dark Text"] = Color3.fromRGB(190, 230, 255) },
    Ocean = { ["Color Hub 1"] = Color3.fromRGB(0, 20, 40), ["Color Hub 2"] = Color3.fromRGB(0, 35, 70), ["Color Stroke"] = Color3.fromRGB(0, 80, 150), ["Color Theme"] = Color3.fromRGB(0, 150, 255), ["Color Text"] = Color3.fromRGB(230, 245, 255), ["Color Dark Text"] = Color3.fromRGB(180, 210, 230) },
    Desert = { ["Color Hub 1"] = Color3.fromRGB(180, 150, 110), ["Color Hub 2"] = Color3.fromRGB(210, 170, 120), ["Color Stroke"] = Color3.fromRGB(140, 70, 30), ["Color Theme"] = Color3.fromRGB(220, 150, 30), ["Color Text"] = Color3.fromRGB(50, 40, 30), ["Color Dark Text"] = Color3.fromRGB(90, 80, 70) },
    Galaxy = { ["Color Hub 1"] = Color3.fromRGB(10, 0, 30), ["Color Hub 2"] = Color3.fromRGB(20, 0, 40), ["Color Stroke"] = Color3.fromRGB(70, 0, 120), ["Color Theme"] = Color3.fromRGB(140, 0, 255), ["Color Text"] = Color3.fromRGB(245, 245, 255), ["Color Dark Text"] = Color3.fromRGB(200, 200, 230) },
    Vintage = { ["Color Hub 1"] = Color3.fromRGB(120, 90, 60), ["Color Hub 2"] = Color3.fromRGB(140, 110, 80), ["Color Stroke"] = Color3.fromRGB(100, 70, 50), ["Color Theme"] = Color3.fromRGB(190, 150, 120), ["Color Text"] = Color3.fromRGB(70, 50, 40), ["Color Dark Text"] = Color3.fromRGB(100, 90, 80) },
    Rainbow = { ["Color Hub 1"] = Color3.fromRGB(240, 240, 240), ["Color Hub 2"] = Color3.fromRGB(255, 255, 255), ["Color Stroke"] = Color3.fromRGB(200, 200, 200), ["Color Theme"] = Color3.fromRGB(255, 100, 100), ["Color Text"] = Color3.fromRGB(30, 30, 30), ["Color Dark Text"] = Color3.fromRGB(90, 90, 90) },
    Midnight = { ["Color Hub 1"] = Color3.fromRGB(0, 0, 20), ["Color Hub 2"] = Color3.fromRGB(5, 5, 30), ["Color Stroke"] = Color3.fromRGB(0, 0, 80), ["Color Theme"] = Color3.fromRGB(50, 50, 255), ["Color Text"] = Color3.fromRGB(250, 250, 255), ["Color Dark Text"] = Color3.fromRGB(190, 190, 220) },
}

local TOKENS = {
    Geometry = { WindowRadius = 14, SidebarRadius = 11, CardRadius = 10, ControlRadius = 8, InputRadius = 7, PopupRadius = 9 },
    Spacing = { XS = 4, SM = 8, MD = 12, LG = 16, XL = 22 },
    Animation = { General = 0.18, Hover = 0.12, Press = 0.09, Tab = 0.18, Popup = 0.18, Toggle = 0.16, Notification = 0.24 },
    Typography = { Title = 18, Subtitle = 11, Section = 14, Body = 13, Small = 11 },
    Dimensions = { Header = 58, Sidebar = 168, MinWidth = 320, MinHeight = 280 },
}

local function validTheme(theme)
    if type(theme) ~= "table" then
        return false
    end
    for _, key in ipairs(REQUIRED_KEYS) do
        if typeof(theme[key]) ~= "Color3" then
            return false
        end
    end
    return true
end

function ThemeManager.new(runService, resourceScope)
    local themes = table.clone(THEMES)
    return setmetatable({
        Themes = themes,
        CurrentName = "Darker",
        Current = themes.Darker,
        Tokens = table.clone(TOKENS),
        Bindings = setmetatable({}, {__mode = "k"}),
        Chroma = setmetatable({}, {__mode = "k"}),
        ChromaEnabled = false,
        RunService = runService,
        ResourceScope = resourceScope,
        ChromaConnection = nil,
        _elapsed = 0,
    }, ThemeManager)
end

function ThemeManager:IsValid(theme)
    return validTheme(theme)
end

function ThemeManager:Get(key)
    return self.Current[key]
end

function ThemeManager:Bind(instance, property, themeKey, customUpdater)
    if not instance or type(property) ~= "string" then
        return false
    end
    local bucket = self.Bindings[instance]
    if not bucket then
        bucket = {}
        self.Bindings[instance] = bucket
    end
    bucket[property] = {Key = themeKey, Updater = customUpdater}
    if customUpdater then
        local ok, err = pcall(customUpdater, self.Current)
        if not ok then
            warn("[JustHub] Theme binding failed: " .. tostring(err))
            return false
        end
    elseif themeKey and self.Current[themeKey] then
        local ok, err = pcall(function()
            instance[property] = self.Current[themeKey]
        end)
        if not ok then
            warn("[JustHub] Theme binding failed: " .. tostring(err))
            return false
        end
    end
    return true
end

function ThemeManager:UpdateBinding(instance, property, themeKey)
    local bucket = self.Bindings[instance]
    if bucket and bucket[property] then
        bucket[property].Key = themeKey
        return true
    end
    return false
end

function ThemeManager:Apply(theme)
    local nextTheme, nextName
    if type(theme) == "string" then
        nextTheme = self.Themes[theme]
        nextName = theme
    else
        nextTheme = theme
        nextName = "Custom"
    end
    if not validTheme(nextTheme) then
        return false, "Unknown or invalid theme"
    end

    self.Current = nextTheme
    self.CurrentName = nextName
    for instance, properties in pairs(self.Bindings) do
        local alive = true
        pcall(function()
            alive = instance.Parent ~= nil
        end)
        if not alive then
            self.Bindings[instance] = nil
        else
            for property, binding in pairs(properties) do
                if not (self.ChromaEnabled and self.Chroma[instance] and self.Chroma[instance][property]) then
                    local ok, err = pcall(function()
                        if binding.Updater then
                            binding.Updater(nextTheme)
                        elseif binding.Key and nextTheme[binding.Key] then
                            instance[property] = nextTheme[binding.Key]
                        end
                    end)
                    if not ok then
                        warn("[JustHub] Theme update failed: " .. tostring(err))
                    end
                end
            end
        end
    end
    return true
end

function ThemeManager:Register(name, definition)
    if type(name) ~= "string" or name == "" or not validTheme(definition) then
        return false, "Theme requires a name and six Color3 fields"
    end
    self.Themes[name] = table.clone(definition)
    return true
end

function ThemeManager:RegisterChroma(instance, property, themeKey)
    if not instance or type(property) ~= "string" then
        return false
    end
    local bucket = self.Chroma[instance]
    if not bucket then
        bucket = {}
        self.Chroma[instance] = bucket
    end
    bucket[property] = themeKey or true
    self:_UpdateChromaConnection()
    return true
end

function ThemeManager:UnregisterChroma(instance, property)
    local bucket = instance and self.Chroma[instance]
    if not bucket then
        return
    end
    if property then
        bucket[property] = nil
        if not next(bucket) then
            self.Chroma[instance] = nil
        end
    else
        self.Chroma[instance] = nil
    end
    self:_UpdateChromaConnection()
end

function ThemeManager:_UpdateChromaConnection()
    local shouldRun = self.ChromaEnabled and next(self.Chroma) ~= nil
    if shouldRun and not self.ChromaConnection then
        self.ChromaConnection = self.ResourceScope:Connect(self.RunService.Heartbeat, function(deltaTime)
            self._elapsed += deltaTime
            if self._elapsed < 1 / 24 then
                return
            end
            self._elapsed = 0
            local color = Color3.fromHSV((os.clock() % 5) / 5, 0.82, 1)
            for instance, properties in pairs(self.Chroma) do
                local alive = false
                pcall(function()
                    alive = instance.Parent ~= nil
                end)
                if not alive then
                    self.Chroma[instance] = nil
                else
                    for property in pairs(properties) do
                        local ok = pcall(function()
                            instance[property] = color
                        end)
                        if not ok then
                            properties[property] = nil
                        end
                    end
                    if not next(properties) then
                        self.Chroma[instance] = nil
                    end
                end
            end
            if not next(self.Chroma) then
                self:_UpdateChromaConnection()
            end
        end)
    elseif not shouldRun and self.ChromaConnection then
        self.ResourceScope:Disconnect(self.ChromaConnection)
        self.ChromaConnection = nil
    end
end

function ThemeManager:SetChroma(enabled)
    self.ChromaEnabled = enabled == true
    if not self.ChromaEnabled then
        for instance, properties in pairs(self.Chroma) do
            for property, themeKey in pairs(properties) do
                if type(themeKey) == "string" and self.Current[themeKey] then
                    pcall(function()
                        instance[property] = self.Current[themeKey]
                    end)
                end
            end
        end
    end
    self:_UpdateChromaConnection()
    return self.ChromaEnabled
end

function ThemeManager:Destroy()
    if self.ChromaConnection then
        self.ResourceScope:Disconnect(self.ChromaConnection)
        self.ChromaConnection = nil
    end
    table.clear(self.Bindings)
    table.clear(self.Chroma)
end

ThemeManager.Defaults = THEMES
ThemeManager.DesignTokens = TOKENS
return ThemeManager
