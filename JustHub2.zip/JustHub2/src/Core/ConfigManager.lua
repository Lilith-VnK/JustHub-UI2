local ConfigManager = {}
ConfigManager.__index = ConfigManager

local SCHEMA_VERSION = 4

local function serialize(value, seen)
    if typeof(value) == "Color3" then
        return {
            __JustHubType = "Color3",
            R = value.R,
            G = value.G,
            B = value.B,
        }
    end
    if type(value) ~= "table" then
        local valueType = type(value)
        if valueType == "string" or valueType == "number" or valueType == "boolean" then
            return value
        end
        if value == nil then
            return nil
        end
        error("Unsupported config value type: " .. valueType, 0)
    end

    seen = seen or {}
    if seen[value] then
        error("Configuration contains a cyclic table", 0)
    end
    seen[value] = true

    local result = {}
    for key, child in pairs(value) do
        if type(key) ~= "string" and type(key) ~= "number" then
            error("Configuration keys must be strings or numbers", 0)
        end
        result[key] = serialize(child, seen)
    end
    seen[value] = nil
    return result
end

local function deserialize(value, depth)
    depth = (depth or 0) + 1
    if depth > 32 then
        error("Configuration nesting limit exceeded", 0)
    end
    if type(value) ~= "table" then
        return value
    end

    local marker = value.__JustHubType or value.__type
    if marker == "Color3" then
        local red = tonumber(value.R)
        local green = tonumber(value.G)
        local blue = tonumber(value.B)
        if not red or not green or not blue then
            error("Configuration contains an invalid Color3 value", 0)
        end
        if red ~= red or green ~= green or blue ~= blue
            or red == math.huge or red == -math.huge
            or green == math.huge or green == -math.huge
            or blue == math.huge or blue == -math.huge then
            error("Configuration contains a non-finite Color3 value", 0)
        end
        return Color3.new(math.clamp(red, 0, 1), math.clamp(green, 0, 1), math.clamp(blue, 0, 1))
    end

    local result = {}
    for key, child in pairs(value) do
        result[key] = deserialize(child, depth)
    end
    return result
end

function ConfigManager.new(httpService, stateManager, storageAdapter, notify)
    return setmetatable({
        HttpService = httpService,
        State = stateManager,
        Storage = storageAdapter,
        Notify = notify,
        SchemaVersion = SCHEMA_VERSION,
    }, ConfigManager)
end

function ConfigManager:Serialize(values)
    return serialize(values)
end

function ConfigManager:Deserialize(values)
    return deserialize(values)
end

function ConfigManager:_CollectValues()
    local values = table.clone(self.State.Values)
    for id, record in pairs(self.State.Registry) do
        if record.ExternalSetter and type(record.Metadata) == "table" then
            local getter = record.Metadata.getValue or record.Metadata.GetValue
            if type(getter) == "function" then
                local ok, value = pcall(getter)
                if ok and value ~= nil then
                    values[id] = value
                elseif not ok then
                    warn("[JustHub] Could not read external control '" .. tostring(id) .. "' for config: " .. tostring(value))
                end
            end
        end
    end
    return values
end

function ConfigManager:Save(fileName)
    local ok, json = pcall(function()
        local payload = {
            __JustHub = {
                Version = SCHEMA_VERSION,
                Framework = "JustHub",
                FrameworkVersion = "3.0.0",
                SavedAt = os.time(),
            },
            Values = serialize(self:_CollectValues()),
        }
        return self.HttpService:JSONEncode(payload)
    end)
    if not ok then
        return false, "JSON encoding failed: " .. tostring(json)
    end

    local writeOk, result = self.Storage:Write(fileName or "JustHub_Config.json", json)
    if not writeOk then
        return false, result
    end
    if self.Notify then
        self.Notify("Save Config", "Saved: " .. tostring(result), 3)
    end
    return true, result
end

function ConfigManager:_ExtractValues(decoded)
    if type(decoded) ~= "table" then
        return nil, "Configuration root must be an object"
    end

    if type(decoded.__JustHub) == "table" then
        local version = tonumber(decoded.__JustHub.Version) or 1
        if version > SCHEMA_VERSION then
            return nil, "Configuration was created by a newer JustHub version"
        end
        if type(decoded.Values) ~= "table" then
            return nil, "Configuration is missing its Values object"
        end
        return deserialize(decoded.Values), version
    end

    -- Legacy format: v2/v3 stored values at the JSON root and could include
    -- an internal transparency metadata node. That node is intentionally ignored.
    local legacy = table.clone(decoded)
    for key, value in pairs(legacy) do
        if type(value) == "table" and value.__JustHubInternal == "TransparencySettings" then
            legacy[key] = nil
        elseif key == "__JustHubMeta" then
            legacy[key] = nil
        end
    end
    return deserialize(legacy), 3
end

function ConfigManager:Load(fileName)
    local readOk, raw, resolvedPath = self.Storage:Read(fileName or "JustHub_Config.json")
    if not readOk then
        return false, raw
    end

    local decodeOk, decoded = pcall(function()
        return self.HttpService:JSONDecode(raw)
    end)
    if not decodeOk then
        return false, "Invalid JSON: " .. tostring(decoded)
    end

    local extractOk, values, version = pcall(function()
        local result, schema = self:_ExtractValues(decoded)
        if not result then
            error(schema, 0)
        end
        return result, schema
    end)
    if not extractOk then
        return false, "Invalid configuration: " .. tostring(values)
    end

    if version < SCHEMA_VERSION then
        -- The v3 metadata contained only hard-coded transparency flags; those
        -- values are deliberately discarded in the new opaque design.
        warn("[JustHub] Migrating legacy configuration schema v" .. tostring(version) .. " to v" .. SCHEMA_VERSION)
    end

    local applyOk, report = self.State:ApplyConfig(values)
    if not applyOk then
        return false, report
    end
    if self.Notify then
        self.Notify("Load Config", "Loaded: " .. tostring(resolvedPath), 3)
    end
    return true, report
end

function ConfigManager:Delete(fileName)
    return self.Storage:Delete(fileName or "JustHub_Config.json")
end

return ConfigManager
